<?php
/**
 *  ------------------------------------------------------------------------
 *  samlSSO
 *
 *  samlSSO was inspired by the initial work of Derrick Smith's
 *  PhpSaml. This project's intend is to address some structural issues
 *  caused by the gradual development of GLPI and the broad amount of
 *  wishes expressed by the community.
 *
 *  Copyright (C) 2024 by Chris Gralike
 *  ------------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of samlSSO plugin for GLPI.
 *
 * samlSSO plugin is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * samlSSO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with samlSSO. If not, see <http://www.gnu.org/licenses/> or
 * https://choosealicense.com/licenses/gpl-3.0/
 *
 * ------------------------------------------------------------------------
 *
 *  @package    samlSSO
 *  @version    1.3.2
 *  @author     Chris Gralike
 *  @copyright  Copyright (c) 2024 by Chris Gralike
 *  @license    GPLv3+
 *  @see        https://github.com/DonutsNL/samlSSO/readme.md
 *  @link       https://github.com/DonutsNL/samlSSO
 *  @since      1.2.0
 * ------------------------------------------------------------------------
 **/

namespace GlpiPlugin\Samlsso\Controller;

use Glpi\Http\Firewall;                                                 // Required to allow anonymous access to ACS route
use Glpi\Controller\AbstractController;                                 // The controller
use Glpi\Security\Attribute\SecurityStrategy;                           // Required to decorate the invoke
use Symfony\Component\HttpFoundation\Request;                           // Required for __invoke
use Symfony\Component\HttpFoundation\Response;                          // Required for __invoke
use Symfony\Component\Routing\Attribute\Route;                          // Required to register controller route
use GlpiPlugin\Samlsso\Exclude;                                         // Required to call Exclude object
use GlpiPlugin\Samlsso\RuleSaml;                                        // Required to call Rules object
use GlpiPlugin\Samlsso\LoginState;                                      //
use GlpiPlugin\Samlsso\LoginFlow\Acs;                                   // Required to call the ACS object
use GlpiPlugin\Samlsso\LoginFlow\Meta;                                  // Required to call Exclude object
use GlpiPlugin\Samlsso\Config\ConfigForm;                               // Required to call Config object
use GlpiPlugin\Samlsso\LoginFlow\LoginFlowForm;                         //
use Glpi\Application\View\TemplateRenderer;


final class SamlSsoController extends AbstractController
{
    ####################################################################
    // ACS route
    public const ACS_ROUTE      = 'front/acs';                          // Route being registered by __class__
    public const ACS_PARAM      = '/{'.LoginState::IDP_ID.'}';
    public const ACS_NAME       = 'samlsso_ACS';                        // Route name

    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]                    // Decorator to disable authentication check
    #[Route(self::ACS_ROUTE.self::ACS_PARAM, name: self::ACS_NAME)]     // Decorator to register route to controller
    public function acs(Request $request): Response                     // What to do if route is invoked.
    {
        (new Acs)->init($request);                                     // Call the ACS handler.
        return new Response();
    }


    ####################################################################
    // SLO route
    public const SLO_ROUTE      = 'front/logout';                       // Route being registered by __class__
    public const SLO_PARAM      = '/{'.LoginState::IDP_ID.'}';
    public const SLO_NAME       = 'samlsso_SLO';                        // Route name

    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]                    // Decorator to disable authentication check
    #[Route(self::SLO_ROUTE, name: self::SLO_NAME)]
    #[Route(self::SLO_ROUTE.self::SLO_PARAM, name: self::SLO_NAME.'_param')] // Decorator to register route to controller
    public function slo(Request $request): Response                     // What to do if route is invoked.
    {
        global $CFG_GLPI;

        ob_start();
        \Html::nullHeader("SamlSSO Logout", '/');
        
        $tplVars = [
            'loginPath' => $CFG_GLPI['url_base'] . '/index.php?noAuto=1'
        ];
        
        echo TemplateRenderer::getInstance()->render('@samlsso/loggedOut.html.twig', $tplVars);
        
        \Html::nullFooter();
        $content = ob_get_clean();

        return new Response($content);
    }


    ####################################################################
    // Meta route
    public const META_ROUTE     = 'front/meta';                         // Route being registered by __class__
    public const META_PARAM     = '/{idpId}';
    public const META_NAME      = 'samlsso_META';                       // Route name

    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]                    // Decorator to disable authentication check
    #[Route(self::META_ROUTE.self::META_PARAM, name: self::META_NAME)]  // Decorator to register route to controller
    public function meta(Request $request): Response                    // What to do if route is invoked.
    {
        return (new Meta)->getSPMeta($request);                         // Call the SPMeta handler.
    }


    ####################################################################
    // Config routes
    public const CONFIG_FILE     = 'front/config.php';                  // Register old route as well
    public const CONFIG_ROUTE    = 'front/config';                      // Route being registered by __class__
    public const CONFIG_NAME     = 'configMain';                        // Route name
    public const CONFIG_PNAME    = 'config';                            // Parent object name

    //#[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]                  // Decorator to disable authentication check
    #[Route(self::CONFIG_ROUTE, name: self::CONFIG_NAME)]               // Decorator to register route to controller
    #[Route(self::CONFIG_FILE, name: self::CONFIG_NAME.'_file')]        // Decorator to register old route to handle GLPI generated menu's
    public function config(Request $request): Response                  // What to do if route is invoked.
    {
        $res = (new ConfigForm)->invoke($request);
        if ($res instanceof Response) {
            return $res;
        }
        return new Response((string)$res);
    }

    // ConfigForm routes
    public const CONFIGFORM_FILE = 'front/config.form.php';             // Register old route as well
    public const CONFIGFORM_ROUTE= 'front/config/form';                 // Route being registered by __class__
    public const CONFIGFORM_NAME = 'configForm';                        // Route name
    public const CONFIGFORM_PNAME= 'config';                            // Parent object name
    //#[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]                  // Decorator to disable authentication check
    #[Route(self::CONFIGFORM_ROUTE, name: self::CONFIGFORM_NAME)]       // Decorator to register route to controller
    #[Route(self::CONFIGFORM_FILE, name: self::CONFIGFORM_NAME.'_file')]// Decorator to register old route to handle GLPI generated menu's
    public function configform(Request $request): Response
    {
        return (new ConfigForm)->invokeForm($request);
    }


    ####################################################################
    // LoginFlowConfig
    public const FLOWFORM_FILE = 'front/loginflow.form.php';
    public const FLOWFORM_ROUTE= 'front/flowconfig';                    // Route being registered by __class__
    public const FLOWFORM_NAME = 'flowMain';                            // Route name
    public const FLOWFORM_PNAME= 'config';                              // Parent object name
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]                    // Decorator to disable authentication check
    #[Route(self::FLOWFORM_ROUTE, name: self::FLOWFORM_NAME)]           // Decorator to register route to controller
    #[Route(self::FLOWFORM_FILE, name: self::FLOWFORM_NAME.'_file')]    // Decorator to register old route to handle GLPI generated menu's
    public function loginflow(Request $request): Response               // What to do if route is invoked.
    {
        (new LoginFlowForm)->init();                                   // Call the ACS handler.
        return new Response();
    }


    ####################################################################
    // Exclude routes
    public const EXCLUDE_ROUTE = 'front/exclude';                       // Route being registered by __class__
    public const EXCLUDE_NAME  = 'excludeMain';                         // Route name
    public const EXCLUDE_PNAME = 'config';                              // Parent object name
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]                    // Decorator to disable authentication check
    #[Route(self::EXCLUDE_ROUTE, name: self::EXCLUDE_NAME)]             // Decorator to register route to controller
    public function exclude(): Response                                 // What to do if route is invoked.
    {
        (new Exclude)->invoke();                                       // Call the ACS handler.
        return new Response();
    }


    ####################################################################
    // Rules routes
    public const RULES_FILE     = 'front/rulesaml.php';                 // Register all route as well because these might be autogenerated
    public const RULES_ROUTE    = 'front/rule';                         // Route being registered by __class__
    public const RULES_NAME     = 'ruleMain';                           // Route name
    public const RULES_PNAME    = 'config';                             // Parent object name
    public const RULESFORM_FILE = 'front/rulesaml.form.php';            // Register old route as well because paths are auto generated
    public const RULESFORM_ROUTE= 'front/ruleForm';                     // Route being registered by __class__
    public const RULESFORM_NAME = 'ruleForm';                           // Route name
    public const RULESFORM_PNAME= 'config';                             // Parent object name


    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]                    // Decorator to disable authentication check
    #[Route(self::RULES_ROUTE, name: self::RULES_NAME)]                 // Decorator to register route to controller
    #[Route(self::RULES_FILE, name: self::RULES_NAME.'_file')]          // Decorator to register route to controller
    public function __invoke(Request $request): Response                // What to do if route is invoked.
    {
        (new RuleSaml)->invoke();                                      // Call the ACS handler.
        return new Response();
    }

    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]                    // Decorator to disable authentication check
    #[Route(self::RULESFORM_ROUTE, name: self::RULESFORM_NAME)]         // Decorator to register route to controller
    #[Route(self::RULESFORM_FILE, name: self::RULESFORM_NAME.'_file')]  // Decorator to register route to controller
    public function itemform(Request $request): Response                // What to do if route is invoked.
    {
        (new RuleSaml)->invokeForm();                                  // Call the ACS handler.
        return new Response();
    }

}
