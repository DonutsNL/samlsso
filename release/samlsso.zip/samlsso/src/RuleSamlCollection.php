<?php
declare(strict_types=1);
/**
 *  ------------------------------------------------------------------------
 *  samlSSO
 *
 *  samlSSO was inspired by the initial work of Derrick Smith's
 *  PhpSaml. This project's intend is to address some structural issues
 *  caused by the gradual development of GLPI and the broad amount of
 *  wishes expressed by the community.
 *
 *  Copyright (C) 2024 by Chris Gralike
 *  ------------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of samlSSO plugin for GLPI.
 *
 * samlSSO plugin is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * samlSSO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with samlSSO. If not, see <http://www.gnu.org/licenses/> or
 * https://choosealicense.com/licenses/gpl-3.0/
 *
 * ------------------------------------------------------------------------
 *
 *  @package    samlSSO
 *  @version    1.3.2
 *  @author     Chris Gralike
 *  @copyright  Copyright (c) 2024 by Chris Gralike
 *  @license    GPLv3+
 *  @see        https://github.com/DonutsNL/samlSSO/readme.md
 *  @link       https://github.com/DonutsNL/samlSSO
 *  @since      1.0.0
 * ------------------------------------------------------------------------
 **/

namespace GlpiPlugin\Samlsso;

use GlpiPlugin\Samlsso\Compat\RuleSamlCollectionCompat;

// Version-selected compatibility layer (GLPI 11 untyped / GLPI 12 typed core
// properties). Must be required before the class below extends the compat one.
require_once __DIR__ . '/compat.php';

/**
 * JIT import rule collection, extending the core RuleCollection through the
 * version-selected compatibility layer: $rightname ('rule_import') and
 * $menu_option ('Saml') are carried by RuleSamlCollectionCompat, version-typed
 * for GLPI 11 and GLPI 12. $stop_on_first_match keeps the core default (false).
 **/
class RuleSamlCollection extends RuleSamlCollectionCompat
{

    /**
     * @see Rule::getCriterias()
     **/
    /**
     * Get the title of the rule collection.
     *
     * @return string Friendly name of the JIT import rules.
     */
    public function getTitle(): string
    {
        return __('JIT import rules', PLUGIN_NAME);
    }

    /**
     * Get the URL for testing the rules.
     * Overrides core RuleCollection to point to the global core rules test endpoint,
     * since the plugin does not ship a custom rules engine test page in its front directory.
     *
     * @return string The test URL.
     */
    public static function getRulesTestURL(): string
    {
        return '/front/rulesengine.test.php';
    }

}
