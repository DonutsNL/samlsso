<?php

namespace GlpiPlugin\Samlsso\Exception;

use Exception;

final class LoginStateException extends Exception {}
