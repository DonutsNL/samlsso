<?php

declare(strict_types=1);
/**
 *  ------------------------------------------------------------------------
 *  samlSSO
 *
 *  samlSSO was inspired by the initial work of Derrick Smith's
 *  PhpSaml. This project's intend is to address some structural issues
 *  caused by the gradual development of GLPI and the broad amount of
 *  wishes expressed by the community.
 *
 *  Copyright (C) 2024 by Chris Gralike
 *  ------------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of samlSSO plugin for GLPI.
 *
 * samlSSO plugin is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * samlSSO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with samlSSO. If not, see <http://www.gnu.org/licenses/> or
 * https://choosealicense.com/licenses/gpl-3.0/
 *
 * ------------------------------------------------------------------------
 *
 *  @package    samlSSO
 *  @version    1.3.2
 *  @author     Chris Gralike
 *  @copyright  Copyright (c) 2024 by Chris Gralike
 *  @license    GPLv3+
 *  @see        https://github.com/DonutsNL/samlSSO/readme.md
 *  @link       https://github.com/DonutsNL/samlSSO
 *  @since      1.0.0
 * ------------------------------------------------------------------------
 **/

namespace GlpiPlugin\Samlsso\Config;

use Session;
use ReflectionClass;
use GlpiPlugin\Samlsso\Config\ConfigItem;
use GlpiPlugin\Samlsso\Config as SamlConfig;
use GlpiPlugin\Samlsso\Controller\SamlSsoController;

/*
 * Class ConfigEntity's job is to populate, evaluate, test, normalize and
 * make sure we always return a consistent, valid, and usable instance of
 * a samlConfiguration thats either based on a template or based on an
 * existing database row
 */

class ConfigEntity extends ConfigItem
{
    /*
     * ConfigEntity can be reflected by this->getConstants(),
     * private constants are not!
     * 32 database fields expected
     */
    public const ID              = 'id';                                     // Database ID
    public const NAME            = 'name';                                   // Configuration name, not used in SAML handling
    public const CONF_DOMAIN     = 'conf_domain';                            // Configuration domain, used to identify saml handled logins
    public const CONF_ICON       = 'conf_icon';                              // Configuration ICON to use in UI elements
    /**
     * @var string Database column: custom image or logo URL for the login button icon.
     */
    public const CONF_ICON_URL   = 'conf_icon_url';
    /**
     * @var string Database column: custom header text displayed above login buttons on the login screen.
     */
    public const LOGIN_HEADER_TEXT = 'login_header_text';
    public const ENFORCE_SSO     = 'enforce_sso';                            // Enforce SSO
    public const PROXIED         = 'proxied';                                // Handle proxied responses (X-forwarded-for)
    public const STRICT          = 'strict';                                 // Enforce encryption
    public const DEBUG           = 'debug';                                  // Enable debug logging
    public const USER_JIT        = 'user_jit';                               // Enable Just In Time user creation
    public const SP_CERTIFICATE  = 'sp_certificate';                         // Service provider certificate
    public const SP_KEY          = 'sp_private_key';                         // Service provider certificate key
    public const SP_KEY_SOURCE   = 'sp_private_key_source';                  // Service provider private key source
    public const SP_NAME_FORMAT  = 'sp_nameid_format';                       // Service provider nameID formatting
    public const IDP_ENTITY_ID   = 'idp_entity_id';                          // Identity provider Entity ID
    public const IDP_SSO_URL     = 'idp_single_sign_on_service';             // Identity provider Single Sign On Url
    public const IDP_SLO_URL     = 'idp_single_logout_service';              // Identity provider Logout Url
    public const IDP_CERTIFICATE = 'idp_certificate';                        // Identity provider certificate
    public const AUTHN_CONTEXT   = 'requested_authn_context';                // Requested authn context (to be provided by Idp)
    public const AUTHN_COMPARE   = 'requested_authn_context_comparison';     // Requested authn context comparison (to be evaluated by Idp)
    public const ENCRYPT_NAMEID  = 'security_nameidencrypted';               // Encrypt nameId field using service provider certificate
    public const SIGN_AUTHN      = 'security_authnrequestssigned';           // Sign authN request using service provider certificate
    /**
     * @var string Database column: flag to force IdP re-authentication on outgoing AuthnRequests.
     */
    public const FORCE_AUTHN     = 'force_authn';
    public const SIGN_SLO_REQ    = 'security_logoutrequestsigned';           // Sign logout request using service provider certificate
    public const SIGN_SLO_RES    = 'security_logoutresponsesigned';          // Sign logout response using service provider certificate
    public const COMPRESS_REQ    = 'compress_requests';                      // Compress all requests
    public const COMPRESS_RES    = 'compress_responses';                     // Compress all responses
    public const XML_VALIDATION  = 'validate_xml';                           // Validate XML messages
    public const DEST_VALIDATION = 'validate_destination';                   // relax destination validation
    public const LOWERCASE_URL   = 'lowercase_url_encoding';                 // lowercaseUrlEncoding
    public const COMMENT         = 'comment';                                // Field for comments on configuration page
    public const IS_ACTIVE       = 'is_active';                              // Toggle SAML config active or disabled
    public const IS_DELETED      = 'is_deleted';
    public const CREATE_DATE     = 'date_creation';
    public const MOD_DATE        = 'date_mod';
    public const SAML_XML_STRUCTURE = 'saml_xml_structure';
    /**
     * @var string Database column: flag to trigger synchronization of user
     *             properties and rules engine rerun on every successful login.
     */
    public const SYNC_ON_LOGIN = 'sync_on_login';
    public const REQUEST_TIMEOUT = 'request_timeout';
    public const INACTIVITY_TIMEOUT = 'inactivity_timeout';
    public const SECURITY_WANTMESSAGESSIGNED = 'security_wantmessagessigned';
    public const SECURITY_WANTASSERTIONSSIGNED = 'security_wantassertionssigned';
    public const SECURITY_WANTASSERTIONSENCRYPTED = 'security_wantassertionsencrypted';
    public const SECURITY_SIGNMETADATA = 'security_signmetadata';
    public const SECURITY_WANTNAMEID = 'security_wantnameid';

    /**
     * Cache for loaded database configurations to prevent duplicate queries within the same request.
     * @var array<int, array|null>
     */
    private static array $dbRowCache = [];

    /**
     * Cache for table column metadata keyed by database instance ID.
     * @var array<int, array<int, array<string, mixed>>>
     */
    private static array $tableColumnsCache = [];

    /**
     * Clear the static database configuration cache (mainly for testing purposes).
     * @return void
     */
    public static function clearCache(): void
    {
        self::$dbRowCache = [];
        self::$tableColumnsCache = [];
    }

    /**
     * True, if an configuration issue is found its set to false.
     */
    private $isValid            = true;


    /**
     * For debugging, shows how entity was populated
     */
    private $populationSource   = null;

    /**
     * Contains all field values of a certain configuration
     */
    protected $fields             = [];

    /**
     * Contains all validation error messages generated during validation
     */
    private $invalidMessages    = [];

    /**
     * The ConfigEntity class constructor
     *
     * @param  int      $id             - Saml configuration ID to fetch, or null for default template
     * @param  array    $options        - Options['template'] what template to use;
     * @return object   ConfigEntity    - returns an instance of populated ConfigEntity;
     */
    public function __construct(int $id = -1, array $options = [])
    {
        if (!$id || $id == -1) {
            // negative identifier equals populate using a template file
            $options = (!empty($options['template'])) ? $options : ['template' => 'default'];
            $this->validateAndPopulateTemplateEntity($options);
        } else {
            // positive identifier equals populate using on a database row
            $this->validateAndPopulateDBEntity($id);
        }
    }


    /**
     * Populates the instance of ConfigEntity using a template.
     *
     * @param  array   $options      - name of the Config[NAME]Tpl class to use as template.
     * @return void
     */
    private function validateAndPopulateTemplateEntity(array $options): void    //NOSONAR we are to lazy to split method further.
    {
        // Create entity based on post inputs
        if (
            $options['template'] == 'post'       &&
            array_key_exists('postData', $options)
        ) {
            $this->populationSource = 'post';
            $configItems = $this->getConstants();
            foreach ($options['postData'] as $field => $value) {
                if (array_search($field, $configItems)) {
                    $this->evaluateItem($field, $value);
                }
            }
            $postedId = isset($options['postData'][self::ID]) ? (int)$options['postData'][self::ID] : -1;
            $postedKeySource = (string)($options['postData'][self::SP_KEY_SOURCE] ?? 'db');
            $postedKeyVal = trim((string)($options['postData'][self::SP_KEY] ?? ''));
            if ($postedId > 0 && $postedKeySource === 'db' && $postedKeyVal === '') {
                $existingConfig = new SamlConfig();
                if ($existingConfig->getFromDB($postedId) && !empty($existingConfig->fields[self::SP_KEY])) {
                    $this->evaluateItem(self::SP_KEY, $existingConfig->fields[self::SP_KEY]);
                }
            }
        } else {
            // Locate our template file
            $templateClass = 'GlpiPlugin\Samlsso\Config\Config' . $options['template'] . 'Tpl';
            $this->populationSource = $templateClass;
            if (!class_exists($templateClass)) {
                //Fallback
                $templateClass = 'GlpiPlugin\Samlsso\Config\ConfigDefaultTpl';
                if (!class_exists($templateClass)) {
                    // Fatal issue.
                    Session::addMessageAfterRedirect(sprintf(__("Could not locate configuration template %s, please verify installation!", PLUGIN_NAME), $templateClass));
                    throw new \RuntimeException("Could not locate configuration template $templateClass, please verify installation!");
                }
            } // Use found template.
            // Perform same validation
            foreach ($templateClass::template() as $field => $value) {
                // Might be issue, we assume the correct fields are declared in returned array.
                $this->evaluateItem($field, $value);
            }
        }
    }


    /**
     * Populates the instance of ConfigEntity using a DB query from the glpisaml config table.
     *
     * @param  int      $id             - id of the database row to fetch
     * @return void
     */
    private function validateAndPopulateDBEntity($id): void
    {
        $this->populationSource = 'Database:' . $id;

        // Get configuration from database;
        if (!array_key_exists($id, self::$dbRowCache)) {
            $config = new SamlConfig();
            if ($config->getFromDB($id)) {
                self::$dbRowCache[$id] = $config->fields;
            } else {
                self::$dbRowCache[$id] = null;
            }
        }

        $fields = self::$dbRowCache[$id];
        if ($fields !== null) {
            // Iterate through fetched fields
            foreach ($fields as $field => $value) {
                // Do validations on all provided fields. All fields need to be
                // verified by GlpiPlugin\Glpisaml\Config\ConfigItem per default.
                $this->evaluateItem((string) $field, $value);
            }
        } else {
            $this->validateAndPopulateTemplateEntity(['template' => 'default']);
            $this->isValid = false;
            $this->invalidMessages[self::ID] = __('Configuration ID not found in database.', PLUGIN_NAME);
        }
        // Do some final consistency check here.
    }


    /**
     * Validates and normalizes configuration fields using checks defined
     * in class GlpiPlugin\Glpisaml\Config\ConfigItem. For instance
     * if defined in ConfigItem, it will convert DB result (string) '1'
     * too (boolean) true in the returned array for type safety purposes.
     *
     * @param  string   $field  - name of the field to validate
     * @param  mixed    $val    - value belonging to the field.
     * @return array            - result of the validation including normalized values.
     * @see https://www.mysqltutorial.org/mysql-basics/mysql-boolean/
     */
    private function evaluateItem(string $field, mixed $value, $invalidate = false): array
    {
        // Note: Clean up using class extend instead of external static call. //NOSONAR
        // Rule: We want coders to be forced to always use configEntity and not create loopholes.   //NOSONAR
        $evaluatedItem = (method_exists(get_parent_class($this), $field)) ? $this->$field($value) : $this->noMethod($field, $value);

        if (
            isset($evaluatedItem[ConfigItem::EVAL])      &&
            $evaluatedItem[ConfigItem::EVAL] == 'valid'
        ) {
            $this->fields[$field] = $evaluatedItem[ConfigItem::VALUE];
        } else {
            // Pass or invalidate
            $this->fields[$field] = ($invalidate) ? '' : $value;
            // Add errormessage
            $this->invalidMessages[$field] = (isset($evaluatedItem[ConfigItem::ERRORS])) ? $evaluatedItem[ConfigItem::ERRORS] : 'UNDEFINED';
            // Mark entity invalid
            $this->isValid = false;
        }
        return $evaluatedItem;
    }


    /**
     * This static function will return the configuration constants
     * defined in this class. Idea is to use this reflection to
     * validate the database fields names, numbers and so forth to detect
     * update caused DB issues.
     *
     * @return array            - defined ConfigEntity class constants.
     * @see https://www.php.net/manual/en/reflectionclass.getconstants.php
     */
    public static function getConstants(): array
    {
        $reflectedObj = new ReflectionClass(__CLASS__);
        return $reflectedObj->getConstants();                  //NOSONAR - ignore S3011 all constants here are intended to be public!
    }


    /**
     * This function will return contextual and actual information about the handled
     * configuration fields. It will also perform advanced validations and correct
     * invalid configuration options before save in database.
     *
     * Intended for generating Config->searchOptions, ConfigForm->showForm().
     *
     * @param  bool     $debug  - If true will only return fields without predefined class Constant and preloaded value.
     * @return array            - ConfigEntity field information
     */
    public function getFields(): array        //NOSONAR - Maybe reduce complexity reduce calls to validateConfigFields?;
    {
        global $DB;
        $fields = [];
        $classConstants = ConfigEntity::getConstants();
        $dbInstanceId = is_object($DB) ? spl_object_id($DB) : 0;
        if (!array_key_exists($dbInstanceId, self::$tableColumnsCache)) {
            $columns = [];
            $sql = 'SHOW COLUMNS FROM ' . SamlConfig::getTable();
            $result = $DB->doQuery($sql);
            if ($result) {
                while ($data = $result->fetch_assoc()) {
                    $columns[] = $data;
                }
            }
            self::$tableColumnsCache[$dbInstanceId] = $columns;
        }
        foreach (self::$tableColumnsCache[$dbInstanceId] as $data) {
            $key = array_search($data['Field'], $classConstants);
            $fields[$data['Field']] = [
                ConfigItem::FIELD       => $data['Field'],
                ConfigItem::TYPE        => $data['Type'],
                ConfigItem::NULL        => $data['Null'],
                ConfigItem::CONSTANT    => $key ? "ConfigEntity::$key" : 'UNDEFINED',
                ConfigItem::VALUE       => (isset($this->fields[$data['Field']])) ? $this->fields[$data['Field']] : null,
            ];
            $fields[$data['Field']] = array_merge($fields[$data['Field']], $this->evaluateItem($data['Field'], (isset($this->fields[$data['Field']])) ? $this->fields[$data['Field']] : ''));
        }
        $fields = $this->validateAdvancedConfig($fields);
        return $fields;
    }


    /**
     * Returns the validated and normalized fields in the ConfigEntity
     * for database insertion. It will not add fields added to the
     * ignoreFields param.
     *
     * @param  array $ignoreFields fields to skip
     * @return array $fields with validated and corrected configuration
     */
    public function getDBFields($ignoreFields = []): array
    {
        $fields = [];
        foreach ($this->getFields() as $key => $value) {
            // https://github.com/DonutsNL/glpisaml/issues/11
            if (is_array($ignoreFields) && !in_array($key, $ignoreFields)) {
                $fields[$key] = $value[ConfigItem::VALUE];
            }
        }
        return $fields;
    }


    /**
     * Fetches the config domain from the populated config entity
     * if the entity is anything else than the default 'youruserdomain.tld' or empty
     * it returns that value or an empty string.
     *
     * @param  array $ignoreFields fields to skip
     * @return array $fields with validated and corrected configuration
     * @since 1.1.3
     */
    public function getConfigDomain(): string
    {
        return (key_exists(ConfigEntity::CONF_DOMAIN, $this->fields) &&
            !empty($this->fields[ConfigEntity::CONF_DOMAIN])     &&
            $this->fields[ConfigEntity::CONF_DOMAIN] != 'youruserdomain.tld') ? $this->fields[ConfigEntity::CONF_DOMAIN] : '';
    }

    /**
     * Returns custom icon image URL if configured.
     *
     * @return string|null
     */
    public function getConfIconUrl(): ?string
    {
        return !empty($this->fields[self::CONF_ICON_URL]) ? (string)$this->fields[self::CONF_ICON_URL] : null;
    }

    /**
     * Returns custom login screen header text if configured.
     *
     * @return string|null
     */
    public function getLoginHeaderText(): ?string
    {
        return !empty($this->fields[self::LOGIN_HEADER_TEXT]) ? (string)$this->fields[self::LOGIN_HEADER_TEXT] : null;
    }


    /**
     * Validate advanced configuration options and correct params if not supported by provided setup.
     *
     * @param  array $fields from getFields()
     * @return array $fields with corrected configuration options
     */
    private function validateAdvancedConfig(array $fields): array
    {
        $disable = false;
        if (isset($fields[self::SP_CERTIFICATE]) && isset($fields[self::SP_KEY])) {
            $spCert = $fields[self::SP_CERTIFICATE][ConfigItem::VALUE] ?? '';
            $spKeySource = $fields[self::SP_KEY_SOURCE][ConfigItem::VALUE] ?? 'db';
            $spKeyInput = $fields[self::SP_KEY][ConfigItem::VALUE] ?? '';

            if (empty($spCert) || empty($spKeyInput)) {
                $disable = true;
            } else {
                $resolvedKey = '';
                if ($spKeySource === 'file') {
                    $realGLPIRoot = realpath(GLPI_ROOT);
                    $realPath = realpath($spKeyInput);
                    if ($realPath === false || $realGLPIRoot === false || str_starts_with($realPath, $realGLPIRoot)) {
                        $fields[self::SP_KEY][ConfigItem::ERRORS] = __('⚠️ Private key file path must be located outside the GLPI root directory (docroot) for security.', PLUGIN_NAME);
                        $fields[self::SP_KEY][ConfigItem::EVAL] = ConfigItem::INVALID;
                        $this->isValid = false;
                        $disable = true;
                    } elseif (!is_readable($realPath) || !is_file($realPath)) {
                        $fields[self::SP_KEY][ConfigItem::ERRORS] = __('⚠️ Private key file does not exist or is not readable.', PLUGIN_NAME);
                        $fields[self::SP_KEY][ConfigItem::EVAL] = ConfigItem::INVALID;
                        $this->isValid = false;
                        $disable = true;
                    } else {
                        $resolvedKey = file_get_contents($realPath) ?: '';
                    }
                } elseif ($spKeySource === 'env') {
                    $envVal = getenv($spKeyInput);
                    if ($envVal === false || empty($envVal)) {
                        $fields[self::SP_KEY][ConfigItem::ERRORS] = __('⚠️ Environment variable is not defined or is empty.', PLUGIN_NAME);
                        $fields[self::SP_KEY][ConfigItem::EVAL] = ConfigItem::INVALID;
                        $this->isValid = false;
                        $disable = true;
                    } else {
                        $resolvedKey = (string)$envVal;
                    }
                } elseif ($spKeySource === 'define') {
                    if (!defined($spKeyInput) || empty(constant($spKeyInput))) {
                        $fields[self::SP_KEY][ConfigItem::ERRORS] = __('⚠️ PHP constant (define) is not defined or is empty.', PLUGIN_NAME);
                        $fields[self::SP_KEY][ConfigItem::EVAL] = ConfigItem::INVALID;
                        $this->isValid = false;
                        $disable = true;
                    } else {
                        $resolvedKey = (string)constant($spKeyInput);
                    }
                } else {
                    $resolvedKey = self::decryptPrivateKey($spKeyInput);
                }

                if (!$disable) {
                    if (!$this->validateCertKeyPairModulus($spCert, $resolvedKey)) {
                        $fields[self::SP_KEY][ConfigItem::ERRORS] = __('⚠️ SP private key does not seem to match provided SP certificates modulus.', PLUGIN_NAME);
                        $fields[self::SP_KEY][ConfigItem::EVAL] = ConfigItem::INVALID;
                        $this->isValid = false;
                        $disable = true;
                    }
                }
            }
        }
        if ($disable) {
            $errormsg = __('⚠️ Will be defaulted to "No" because the provided SP certificate does not look valid!', PLUGIN_NAME);
            // Strict cannot be enabled without valid certificate!
            if (isset($fields[configEntity::ENCRYPT_NAMEID]) && $fields[configEntity::ENCRYPT_NAMEID][configItem::VALUE]) {
                $fields[configEntity::ENCRYPT_NAMEID][configItem::VALUE] = false;
                $fields[configEntity::ENCRYPT_NAMEID][configItem::ERRORS] = $errormsg;
            }
            // Strict cannot be enabled without valid certificate!
            if (isset($fields[configEntity::SIGN_AUTHN]) && $fields[configEntity::SIGN_AUTHN][configItem::VALUE]) {
                $fields[configEntity::SIGN_AUTHN][configItem::VALUE] = false;
                $fields[configEntity::SIGN_AUTHN][configItem::ERRORS] = $errormsg;
            }
            // Strict cannot be enabled without valid certificate!
            if (isset($fields[configEntity::SIGN_SLO_REQ]) && $fields[configEntity::SIGN_SLO_REQ][configItem::VALUE]) {
                $fields[configEntity::SIGN_SLO_REQ][configItem::VALUE] = false;
                $fields[configEntity::SIGN_SLO_REQ][configItem::ERRORS] = $errormsg;
            }
            // Strict cannot be enabled without valid certificate!
            if (isset($fields[configEntity::SIGN_SLO_RES]) && $fields[configEntity::SIGN_SLO_RES][configItem::VALUE]) {
                $fields[configEntity::SIGN_SLO_RES][configItem::VALUE] = false;
                $fields[configEntity::SIGN_SLO_RES][configItem::ERRORS] = $errormsg;
            }
        }

        /**
         * Disable inbound security options if strict mode is disabled
         * and attach a warning message explaining they are not enforced.
         */
        if (isset($fields[configEntity::STRICT])) {
            $strict = (bool)($fields[configEntity::STRICT][configItem::VALUE] ?? false);
            if (!$strict) {
                $strictWarning = __('⚠️ These fields are only enforced when strict mode is enabled. Your environment is at risk without strict mode.', PLUGIN_NAME);
                $inboundFields = [
                    configEntity::SECURITY_WANTMESSAGESSIGNED,
                    configEntity::SECURITY_WANTASSERTIONSSIGNED,
                    configEntity::SECURITY_WANTASSERTIONSENCRYPTED,
                    configEntity::SECURITY_WANTNAMEID
                ];
                foreach ($inboundFields as $secField) {
                    if (isset($fields[$secField])) {
                        $fields[$secField][configItem::VALUE] = false;
                        $fields[$secField][configItem::ERRORS] = $strictWarning;
                    }
                }
            }
        }

        // Enforce option check for multiple active IDPs.
        // If there are more than one active and configured IDPs, we automatically disable the enforce option
        // and display a warning inline in the form.
        global $DB;
        $isActive = (int)($fields[configEntity::IS_ACTIVE][configItem::VALUE] ?? 0);
        $isDeleted = (int)($fields[configEntity::IS_DELETED][configItem::VALUE] ?? 0);

        if ($isActive === 1 && $isDeleted === 0) {
            $id = $fields[configEntity::ID][configItem::VALUE] ?? null;
            $where = [
                configEntity::IS_ACTIVE  => 1,
                configEntity::IS_DELETED => 0
            ];
            if ($id !== null && is_numeric($id) && $id > 0) {
                $where['NOT'] = [configEntity::ID => (int)$id];
            }

            $otherActiveCount = count(iterator_to_array($DB->request([
                'FROM'  => SamlConfig::getTable(),
                'WHERE' => $where
            ])));

            if ($otherActiveCount > 0) {
                $fields[configEntity::ENFORCE_SSO][configItem::VALUE] = 0;
                $fields[configEntity::ENFORCE_SSO][configItem::ERRORS] = __('⚠️ IDPs cannot be enforced if more than one is present in the IDP list.', PLUGIN_NAME);
            }
        }

        return $fields;
    }


    /**
     * This function will return specific config field if it exists
     *
     * @param  string   $fieldName  - Name of the configuration item we are looking for, use class constants.
     * @return string|bool          - Value of the configuration or (bool) false if not found.
     */
    public function getField(string $fieldName): string|bool
    {
        if (
            key_exists($fieldName, $this->fields) &&
            is_numeric($this->fields[$fieldName]) &&
            !in_array($fieldName, [self::ID, self::REQUEST_TIMEOUT, self::INACTIVITY_TIMEOUT], true)
        ) {
            return (bool) $this->fields[$fieldName];
        } elseif (key_exists($fieldName, $this->fields)) {
            return (string) $this->fields[$fieldName];
        } else {
            return false;
        }
    }


    /**
     * This function will return all registered error messages
     *
     * @return array           - Value of the configuration or (bool) false if not found.
     */
    public function getErrorMessages(): array
    {
        return (count($this->invalidMessages) > 0) ? $this->invalidMessages : [];
    }


    /**
     * Returns the validity state of the currently loaded ConfigEntity
     * @return bool
     */
    public function isValid(): bool
    {
        return (bool) $this->isValid;
    }


    /**
     * Returns whether the currently loaded ConfigEntity is active.
     *
     * @return bool
     */
    public function isActive(): bool
    {
        return (bool) ($this->fields[ConfigEntity::IS_ACTIVE] ?? false);
    }


    /**
     * Returns whether the currently loaded ConfigEntity is marked as deleted.
     *
     * @return bool
     */
    public function isDeleted(): bool
    {
        return (bool) ($this->fields[ConfigEntity::IS_DELETED] ?? false);
    }


    /**
     * Returns the validity state of the currently loaded ConfigEntity
     * @return bool
     */
    public function getRequestedAuthnContextArray(): array
    {
        $context = (string)($this->fields[ConfigEntity::AUTHN_CONTEXT] ?? '');
        if (str_contains($context, ':')) {
            return explode(':', $context);
        } else {
            return [$context];
        }
    }

    /**
     * Resolves the Service Provider private key from its configured source.
     *
     * @param string $source The key source ('db', 'file', or 'env')
     * @param string $input The key value/path/variable name
     * @return string The private key content, or empty string on failure
     */
    private function resolvePrivateKey(string $source, string $input): string
    {
        if (empty($input)) {
            return '';
        }
        if ($source === 'file') {
            $realGLPIRoot = realpath(GLPI_ROOT);
            $realPath = realpath($input);
            if ($realPath === false || $realGLPIRoot === false || str_starts_with($realPath, $realGLPIRoot)) {
                return '';
            }
            if (is_readable($realPath) && is_file($realPath)) {
                return file_get_contents($realPath) ?: '';
            }
            return '';
        } elseif ($source === 'env') {
            return (string)getenv($input);
        } elseif ($source === 'define') {
            return defined($input) ? (string)constant($input) : '';
        }
        return self::decryptPrivateKey($input);
    }

    /**
     * Decrypts a private key if it was encrypted with GLPIKey.
     * If the string already starts with '-----BEGIN' or GLPIKey is unavailable/fails, returns the input.
     *
     * @param string $keyInput
     * @return string
     */
    public static function decryptPrivateKey(string $keyInput): string
    {
        $trimmed = trim($keyInput);
        if (empty($trimmed) || str_starts_with($trimmed, '-----BEGIN')) {
            return $keyInput;
        }

        if (class_exists('\GLPIKey')) {
            try {
                $glpiKey = new \GLPIKey();
                $decrypted = $glpiKey->decrypt($keyInput);
                if (!empty($decrypted) && str_starts_with(trim($decrypted), '-----BEGIN')) {
                    return $decrypted;
                }
            } catch (\Throwable $e) {
                // Return original input if decryption fails
            }
        }

        return $keyInput;
    }

    /**
     * Encrypts a private key using GLPIKey if available and not already encrypted.
     *
     * @param string $keyInput
     * @return string
     */
    public static function encryptPrivateKey(string $keyInput): string
    {
        $trimmed = trim($keyInput);
        if (empty($trimmed)) {
            return '';
        }

        if (str_starts_with($trimmed, '-----BEGIN') && class_exists('\GLPIKey')) {
            try {
                $glpiKey = new \GLPIKey();
                $encrypted = $glpiKey->encrypt($keyInput);
                if (!empty($encrypted)) {
                    return $encrypted;
                }
            } catch (\Throwable $e) {
                // Fallback to original input if encryption fails
            }
        }

        return $keyInput;
    }

    /**
     * Generates a self-signed X.509 certificate and private key pair using OpenSSL with configurable parameters.
     *
     * @param string|null $commonName Common Name for the certificate subject, defaults to GLPI host
     * @param int $daysValid Validity period in days (defaults to 1095 = 3 years, bounded between 30 and 3650)
     * @param string $keyType Cryptographic key type ('RSA' or 'EC', defaults to 'RSA')
     * @param int $keyBits RSA key bit length (2048, 3072, 4096 - minimum 2048)
     * @param string $curveName EC curve name ('prime256v1', 'secp384r1', 'secp521r1' - minimum 256 bits)
     * @param string $digestAlg Message digest algorithm ('sha256', 'sha384', 'sha512' - defaults to 'sha256')
     * @return array|false Returns associative array with 'certificate' and 'private_key' strings, or false on failure
     */
    public static function generateSelfSignedCertificate(
        ?string $commonName = null,
        int $daysValid = 1095,
        string $keyType = 'RSA',
        int $keyBits = 2048,
        string $curveName = 'prime256v1',
        string $digestAlg = 'sha256'
    ): array|false {
        if (!extension_loaded('openssl') || !function_exists('openssl_pkey_new')) {
            return false;
        }

        global $CFG_GLPI;

        if (empty($commonName)) {
            $urlBase = (string)($CFG_GLPI['url_base'] ?? '');
            $host = !empty($urlBase) ? parse_url($urlBase, PHP_URL_HOST) : null;
            $commonName = !empty($host) ? (string)$host : 'glpi-saml-sp';
        } else {
            $commonName = substr(trim((string)preg_replace('/[^\w.\-]/', '', $commonName)), 0, 64);
            if (empty($commonName)) {
                $commonName = 'glpi-saml-sp';
            }
        }

        // Clamp validity period to between 30 days and 3650 days (10 years)
        $daysValid = max(30, min(3650, $daysValid));

        // Enforce community-accepted digest algorithms
        $digestAlg = strtolower(trim($digestAlg));
        if (!in_array($digestAlg, ['sha256', 'sha384', 'sha512'], true)) {
            $digestAlg = 'sha256';
        }

        $keyType = strtoupper(trim($keyType));
        if ($keyType === 'EC') {
            // Enforce community-accepted elliptic curves (minimum 256 bits)
            $allowedCurves = ['prime256v1', 'secp384r1', 'secp521r1'];
            if (!in_array($curveName, $allowedCurves, true)) {
                $curveName = 'prime256v1';
            }
            $privKeyConfig = [
                'curve_name'       => $curveName,
                'private_key_type' => OPENSSL_KEYTYPE_EC,
            ];
        } else {
            // Default to RSA. Enforce community-accepted minimum key length (NIST/BSI standard: >= 2048 bits)
            $keyType = 'RSA';
            $allowedBits = [2048, 3072, 4096];
            if (!in_array($keyBits, $allowedBits, true)) {
                if ($keyBits < 2048) {
                    return false; // Strictly disallow sub-standard/weak keys
                }
                $keyBits = 2048;
            }
            $privKeyConfig = [
                'private_key_bits' => $keyBits,
                'private_key_type' => OPENSSL_KEYTYPE_RSA,
            ];
        }

        $dn = [
            'commonName'             => $commonName,
            'organizationName'       => 'GLPI SAML Service Provider',
            'organizationalUnitName' => 'IT Department',
        ];

        $privKeyRes = openssl_pkey_new($privKeyConfig);
        if ($privKeyRes === false) {
            return false;
        }

        $csr = openssl_csr_new($dn, $privKeyRes, ['digest_alg' => $digestAlg]);
        if ($csr === false) {
            return false;
        }

        $certRes = openssl_csr_sign($csr, null, $privKeyRes, $daysValid, ['digest_alg' => $digestAlg]);
        if ($certRes === false) {
            return false;
        }

        $certOut = '';
        $privKeyOut = '';
        if (!openssl_x509_export($certRes, $certOut) || !openssl_pkey_export($privKeyRes, $privKeyOut)) {
            return false;
        }

        return [
            'certificate' => trim($certOut),
            'private_key' => trim($privKeyOut),
        ];
    }

    /**
     * Populates and returns the configuration array for the PHP-saml library.
     *
     * @return          array   $config
     * @since           1.0.0
     * @example         https://github.com/SAML-Toolkits/php-saml/blob/master/settings_example.php
     */
    public function getPhpSamlConfig(): array
    {
        global $CFG_GLPI;
        if ($this->isValid()) {

            return [
                'strict'                                => (bool) $this->fields[ConfigEntity::STRICT],
                'debug'                                 => (bool) $this->fields[ConfigEntity::DEBUG],
                'baseurl'                               => null,
                'sp' => [
                    'entityId'                          => $CFG_GLPI['url_base'] . '/',
                    'assertionConsumerService'          => [
                        'url'                           => samlsso_webdir() . SamlSsoController::ACS_ROUTE . '/' . $this->fields[ConfigEntity::ID],
                    ],
                    'singleLogoutService'               => [
                        'url'                           => samlsso_webdir() . SamlSsoController::SLO_ROUTE,
                    ],
                    'x509cert'                          => $this->fields[ConfigEntity::SP_CERTIFICATE],
                    'privateKey'                        => self::decryptPrivateKey($this->resolvePrivateKey(
                        $this->fields[self::SP_KEY_SOURCE] ?? 'db',
                        $this->fields[self::SP_KEY] ?? ''
                    )),
                    'NameIDFormat'                      => (isset($this->fields[ConfigEntity::SP_NAME_FORMAT]) ? $this->fields[ConfigEntity::SP_NAME_FORMAT]
                        : 'unspecified'),
                ],
                'idp'                                   => [
                    'entityId'                          => $this->fields[ConfigEntity::IDP_ENTITY_ID],
                    'singleSignOnService'               => [
                        'url'                           => $this->fields[ConfigEntity::IDP_SSO_URL],
                    ],
                    'singleLogoutService'               => [
                        'url'                           => $this->fields[ConfigEntity::IDP_SLO_URL],
                    ],
                    'x509cert'                          => $this->fields[ConfigEntity::IDP_CERTIFICATE],
                ],
                'compress'                              => [
                    'requests'                          => (bool) $this->fields[ConfigEntity::COMPRESS_REQ],
                    'responses'                         => (bool) $this->fields[ConfigEntity::COMPRESS_RES],
                ],
                'security'                              => [
                    'nameIdEncrypted'                   => (bool) $this->fields[ConfigEntity::ENCRYPT_NAMEID],
                    'authnRequestsSigned'               => (bool) $this->fields[ConfigEntity::SIGN_AUTHN],
                    'forceAuthn'                        => (bool) ($this->fields[ConfigEntity::FORCE_AUTHN] ?? false),
                    'logoutRequestSigned'               => (bool) $this->fields[ConfigEntity::SIGN_SLO_REQ],
                    'logoutResponseSigned'              => (bool) $this->fields[ConfigEntity::SIGN_SLO_RES],
                    'wantMessagesSigned'                => (bool)$this->fields[ConfigEntity::SECURITY_WANTMESSAGESSIGNED],
                    'wantAssertionsSigned'              => (bool)$this->fields[ConfigEntity::SECURITY_WANTASSERTIONSSIGNED],
                    'wantAssertionsEncrypted'           => (bool)$this->fields[ConfigEntity::SECURITY_WANTASSERTIONSENCRYPTED],
                    'signMetadata'                      => (bool)$this->fields[ConfigEntity::SECURITY_SIGNMETADATA],
                    'wantNameId'                        => (bool)$this->fields[ConfigEntity::SECURITY_WANTNAMEID],
                    // Set true or don't present this parameter and you will get an AuthContext 'exact' 'urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport'
                    // Set an array with the possible auth context values: array ('urn:oasis:names:tc:SAML:2.0:ac:classes:Password', 'urn:oasis:names:tc:SAML:2.0:ac:classes:X509'),
                    'requestedAuthnContext'             => $this->getAuthn($this->fields[ConfigEntity::AUTHN_CONTEXT]),
                    'requestedAuthnContextComparison'   => (isset($this->fields[ConfigEntity::AUTHN_COMPARE]) ? $this->fields[ConfigEntity::AUTHN_COMPARE] : 'exact'),
                    'wantXMLValidation'                 => (bool) $this->fields[ConfigEntity::XML_VALIDATION],
                    'relaxDestinationValidation'        => (bool) $this->fields[ConfigEntity::DEST_VALIDATION],

                    // Algorithm that the toolkit will use on signing process. Options:
                    //    'http://www.w3.org/2000/09/xmldsig#rsa-sha1'
                    //    'http://www.w3.org/2000/09/xmldsig#dsa-sha1'
                    //    'http://www.w3.org/2001/04/xmldsig-more#rsa-sha256'
                    //    'http://www.w3.org/2001/04/xmldsig-more#rsa-sha384'
                    //    'http://www.w3.org/2001/04/xmldsig-more#rsa-sha512'
                    // Notice that sha1 is a deprecated algorithm and should not be used
                    'signatureAlgorithm'            => 'http://www.w3.org/2001/04/xmldsig-more#rsa-sha256',
                    //'signatureAlgorithm' => XMLSecurityKey::RSA_SHA256,

                    // Algorithm that the toolkit will use on digest process. Options:
                    //    'http://www.w3.org/2000/09/xmldsig#sha1'
                    //    'http://www.w3.org/2001/04/xmlenc#sha256'
                    //    'http://www.w3.org/2001/04/xmldsig-more#sha384'
                    //    'http://www.w3.org/2001/04/xmlenc#sha512'
                    // Notice that sha1 is a deprecated algorithm and should not be used
                    'digestAlgorithm'               => 'http://www.w3.org/2001/04/xmlenc#sha256',
                    'lowercaseUrlencoding'          => (bool) $this->fields[ConfigEntity::LOWERCASE_URL],
                ]
            ];
        } else {
            // ConfigEntity was not usable!
            return [];
        }
    }

    /**
     * Calculates correct AuthN required for SAML request
     *
     * @return          array|bool   $config
     * @since           1.0.0
     * @example         https://github.com/SAML-Toolkits/php-saml/blob/master/settings_example.php
     */
    private static function getAuthn($value): array|bool
    {
        if (preg_match('/^none,.+/i', $value)) {
            $array  = explode(':', $value);
            $output = array();
            foreach ($array as $item) {
                switch ($item) {
                    case 'PasswordProtectedTransport':
                        $output[] = 'urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport';
                        break;
                    case 'Password':
                        $output[] = 'urn:oasis:names:tc:SAML:2.0:ac:classes:Password';
                        break;
                    case 'X509':
                        $output[] = 'urn:oasis:names:tc:SAML:2.0:ac:classes:X509';
                        break;
                    default:
                        $output[] = '';
                        break;
                }
            }
            return $output;
        } else {
            return false;
        }
    }

    /**
     * Update the anonymized SAML XML structure in the database.
     *
     * @param string $anonymizedXml The sanitized XML structure.
     * @return void
     */
    public function updateXmlStructure(string $anonymizedXml): void
    {
        $id = $this->getField(self::ID);
        if ($id && (int)$id > 0) {
            // Load current configuration as array from this entity's fields
            $postData = $this->fields;
            // Set the new XML structure
            $postData[self::SAML_XML_STRUCTURE] = $anonymizedXml;
            
            // Re-validate everything using ConfigEntity post template to guarantee typesafety and strict validation
            $updatedEntity = new ConfigEntity(-1, ['template' => 'post', 'postData' => new \ArrayIterator($postData)]);
            if ($updatedEntity->isValid()) {
                $fields = $updatedEntity->getDBFields([self::CREATE_DATE, self::IS_DELETED]);
                $config = new SamlConfig();
                $config->update($fields);
                $this->fields[self::SAML_XML_STRUCTURE] = $anonymizedXml;
                self::$dbRowCache[(int)$id] = $this->fields;
            }
        }
    }

    /**
     * Anonymize SAML XML response by stripping out certificate data, signatures,
     * digests, and replacing element text content with generic placeholders.
     *
     * @param string $xml Raw SAML Response XML.
     * @return string Sanitized XML.
     */
    public static function anonymizeXml(string $xml): string
    {
        if (empty($xml)) {
            return '';
        }

        $dom = new \DOMDocument();
        $old_entity_loader = null;
        if (\PHP_VERSION_ID < 80000) {
            $old_entity_loader = libxml_disable_entity_loader(true);
        }
        
        $dom->preserveWhiteSpace = false;
        $dom->formatOutput = true;

        if (!@$dom->loadXML($xml, LIBXML_NONET | LIBXML_NOCDATA)) {
            if (\PHP_VERSION_ID < 80000 && $old_entity_loader !== null) {
                libxml_disable_entity_loader($old_entity_loader);
            }
            return 'Invalid XML response';
        }
        
        if (\PHP_VERSION_ID < 80000 && $old_entity_loader !== null) {
            libxml_disable_entity_loader($old_entity_loader);
        }

        self::anonymizeNode($dom->documentElement);

        return $dom->saveXML() ?: 'Error processing XML';
    }

    /**
     * Recursively sanitize XML nodes.
     *
     * @param \DOMNode $node The node to sanitize.
     * @return void
     */
    private static function anonymizeNode(\DOMNode $node): void
    {
        $cryptoTags = ['Signature', 'SignatureValue', 'DigestValue', 'X509Certificate', 'CipherValue', 'EncryptedData'];
        
        $toRemove = [];
        foreach ($node->childNodes as $child) {
            if ($child->nodeType === XML_ELEMENT_NODE) {
                $localName = $child->localName ?: $child->nodeName;
                if (in_array($localName, $cryptoTags, true)) {
                    $toRemove[] = $child;
                } else {
                    self::anonymizeNode($child);
                }
            }
        }

        foreach ($toRemove as $child) {
            $node->removeChild($child);
        }

        $allowedAttributes = ['Name', 'FriendlyName', 'NameFormat', 'Format', 'Version'];
        if ($node->attributes) {
            foreach ($node->attributes as $attr) {
                if (str_starts_with($attr->nodeName, 'xmlns') || in_array($attr->nodeName, $allowedAttributes, true)) {
                    continue;
                }
                $attr->nodeValue = '[STRIPPED]';
            }
        }

        if ($node->childNodes->length === 1 && $node->firstChild->nodeType === XML_TEXT_NODE) {
            $val = trim($node->firstChild->nodeValue);
            if ($val !== '') {
                $node->firstChild->nodeValue = '[STRIPPED]';
            }
        }
    }
}
