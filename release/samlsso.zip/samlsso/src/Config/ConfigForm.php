<?php
declare(strict_types=1);
/**
 *  ------------------------------------------------------------------------
 *  samlSSO
 *
 *  samlSSO was inspired by the initial work of Derrick Smith's
 *  PhpSaml. This project's intend is to address some structural issues
 *  caused by the gradual development of GLPI and the broad amount of
 *  wishes expressed by the community.
 *
 *  Copyright (C) 2024 by Chris Gralike
 *  ------------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of samlSSO plugin for GLPI.
 *
 * samlSSO plugin is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * samlSSO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with samlSSO. If not, see <http://www.gnu.org/licenses/> or
 * https://choosealicense.com/licenses/gpl-3.0/
 *
 * ------------------------------------------------------------------------
 *
 *  @package    samlSSO
 *  @version    1.4.0
 *  @author     Chris Gralike
 *  @copyright  Copyright (c) 2024 by Chris Gralike
 *  @license    GPLv3+
 *  @see        https://github.com/DonutsNL/samlSSO/readme.md
 *  @link       https://github.com/DonutsNL/samlSSO
 *  @since      1.0.0
 * ------------------------------------------------------------------------
 **/

namespace GlpiPlugin\Samlsso\Config;


use Html;
use Search;
use Session;
use Toolbox;
use GlpiPlugin\Samlsso\Config;
use GlpiPlugin\Samlsso\ClaimMap;
use GlpiPlugin\Samlsso\ScimLink;
use GlpiPlugin\Samlsso\LoginState;
use GlpiPlugin\Samlsso\LoginFlow\User as SamlUser;
use GlpiPlugin\Samlsso\Scim\ScimAuthenticator;
use Glpi\Application\View\TemplateRenderer;
use OneLogin\Saml2\Constants as Saml2Const;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use GlpiPlugin\Samlsso\Controller\SamlSsoController;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class Handles the Configuration front/config.form.php Form
 */
class ConfigForm    //NOSONAR complexity by design.
{
    /**
     * Handles the form calls from the ConfigController and loads the
     * config idps listing (first screen before selecting a specific config)
     *
     * @param Request $request  Incoming HTTP request
     * @return Response|RedirectResponse|void
     */
    public function invoke(Request $request)
    {
        Session::checkRight('config', READ);
        $action = (string) $request->get('action', '');

        // Handle bulk export (download) action - requires config UPDATE right to export secrets
        if ($action === 'backup_all') {
            Session::checkRight('config', UPDATE);
            return $this->exportAllConfigs();
        }

        // Handle bulk restore (upload) action - requires config UPDATE right
        if ($action === 'restore_all' && $request->isMethod('POST')) {
            Session::checkRight('config', UPDATE);
            return $this->restoreAllConfigs($request);
        }
        $this->displayUIHeader();
        $this->renderBackupRestoreCard();
        Search::show(Config::class);
    }


    /**
     * Render the Backup & Restore card above the configuration listing.
     *
     * @return void
     */
    private function renderBackupRestoreCard(): void
    {
        if (!Session::haveRight('config', UPDATE)) {
            return;
        }

        TemplateRenderer::getInstance()->display(
            '@samlsso/configBackupRestore.html.twig',
            [
                'plugin'      => PLUGIN_NAME,
                'export_url'  => samlsso_webdir() . SamlSsoController::CONFIG_ROUTE . '?action=backup_all',
                'restore_url' => samlsso_webdir() . SamlSsoController::CONFIG_ROUTE . '?action=restore_all',
                'csrf_token'  => method_exists(\Session::class, 'getNewCSRFToken') ? \Session::getNewCSRFToken() : '',
            ]
        );
    }


    /**
     * Export all IDP configurations and their claim mappings as a single JSON file download.
     *
     * @return Response
     */
    private function exportAllConfigs(): Response
    {
        global $DB;

        $configs = [];
        $configsTable   = Config::getTable();
        $claimMapTable  = ClaimMap::getTable();
        $exportFields   = [
            ConfigEntity::ID, ConfigEntity::NAME, ConfigEntity::CONF_DOMAIN,
            ConfigEntity::CONF_ICON, ConfigEntity::CONF_ICON_URL, ConfigEntity::LOGIN_HEADER_TEXT,
            ConfigEntity::ENFORCE_SSO, ConfigEntity::PROXIED,
            ConfigEntity::STRICT, ConfigEntity::DEBUG, ConfigEntity::USER_JIT, ConfigEntity::FORCE_AUTHN,
            ConfigEntity::SYNC_ON_LOGIN, ConfigEntity::REQUEST_TIMEOUT, ConfigEntity::INACTIVITY_TIMEOUT,
            ConfigEntity::SECURITY_WANTMESSAGESSIGNED,
            ConfigEntity::SECURITY_WANTASSERTIONSSIGNED,
            ConfigEntity::SECURITY_WANTASSERTIONSENCRYPTED,
            ConfigEntity::SECURITY_SIGNMETADATA,
            ConfigEntity::SECURITY_WANTNAMEID,
            ConfigEntity::SP_CERTIFICATE, ConfigEntity::SP_KEY_SOURCE, ConfigEntity::SP_NAME_FORMAT,
            ConfigEntity::IDP_ENTITY_ID, ConfigEntity::IDP_SSO_URL, ConfigEntity::IDP_SLO_URL,
            ConfigEntity::IDP_CERTIFICATE, ConfigEntity::AUTHN_CONTEXT, ConfigEntity::AUTHN_COMPARE,
            ConfigEntity::ENCRYPT_NAMEID, ConfigEntity::SIGN_AUTHN, ConfigEntity::SIGN_SLO_REQ,
            ConfigEntity::SIGN_SLO_RES, ConfigEntity::COMPRESS_REQ, ConfigEntity::COMPRESS_RES,
            ConfigEntity::XML_VALIDATION, ConfigEntity::DEST_VALIDATION, ConfigEntity::LOWERCASE_URL,
            ConfigEntity::SCIM_ENABLED, ConfigEntity::SCIM_TOKEN_SOURCE, ConfigEntity::SCIM_ALLOWED_IPS,
            ConfigEntity::SCIM_DEPROVISION, ConfigEntity::SCIM_GROUP_POLICY,
            ConfigEntity::COMMENT, ConfigEntity::IS_ACTIVE,
        ];

        // Fetch all non-deleted configurations
        $cfgIterator = $DB->request([
            'FROM'  => $configsTable,
            'WHERE' => [ConfigEntity::IS_DELETED => 0],
        ]);

        foreach ($cfgIterator as $row) {
            // Collect only known export fields
            $configFields = [];
            foreach ($exportFields as $field) {
                $configFields[$field] = $row[$field] ?? null;
            }

            // Collect associated claim mappings for this config
            $claimMappings = [];
            $cmIterator = $DB->request([
                'FROM'  => $claimMapTable,
                'WHERE' => [ClaimMap::CONFIGS_ID => (int)$row[ConfigEntity::ID]],
            ]);
            foreach ($cmIterator as $cmRow) {
                $claimMappings[] = [
                    ClaimMap::TARGET_TYPE   => (string)($cmRow[ClaimMap::TARGET_TYPE]   ?? ClaimMapItem::TARGET_TYPE_USER_FIELD),
                    ClaimMap::GLPI_FIELD    => (string)($cmRow[ClaimMap::GLPI_FIELD]    ?? ''),
                    ClaimMap::SAML_CLAIM    => (string)($cmRow[ClaimMap::SAML_CLAIM]    ?? ''),
                    ClaimMap::DEFAULT_VALUE => (string)($cmRow[ClaimMap::DEFAULT_VALUE] ?? ''),
                    ClaimMap::IS_REQUIRED   => (int)($cmRow[ClaimMap::IS_REQUIRED]      ?? 0),
                ];
            }

            $configs[] = [
                'config'        => $configFields,
                'claim_maps'    => $claimMappings,
            ];
        }

        $payload = [
            'schema_version'    => '1',
            'plugin_version'    => PLUGIN_SAMLSSO_VERSION,
            'exported_at'       => date('c'),
            'configurations'    => $configs,
        ];

        $json     = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $filename = 'samlsso_backup_' . date('Ymd_His') . '.json';

        // Note: do NOT send Content-Length — GLPI's response stack may gzip or buffer
        // the body after this point, causing a mismatch that silently truncates the download.
        return new Response($json, 200, [
            'Content-Type'        => 'application/json; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            'Cache-Control'       => 'no-cache, no-store, must-revalidate',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }


    /**
     * Restore all IDP configurations from an uploaded JSON backup file.
     * This is a clean restore: all existing configurations and claim mappings
     * are removed before the backup data is recreated with original IDs.
     *
     * @param  Request $request Incoming HTTP request containing uploaded file
     * @return RedirectResponse
     */
    private function restoreAllConfigs(Request $request): RedirectResponse
    {
        Session::checkRight('config', UPDATE);
        global $DB;

        // --- 1. Read and parse the uploaded JSON file ---
        $uploadedFile = $request->files->get('restore_file');
        if ($uploadedFile === null || !$uploadedFile->isValid()) {
            Session::addMessageAfterRedirect(__('Restore failed: no valid backup file was uploaded.', PLUGIN_NAME), false, ERROR);
            return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIG_ROUTE);
        }

        $json = file_get_contents($uploadedFile->getPathname());
        if ($json === false || trim($json) === '') {
            Session::addMessageAfterRedirect(__('Restore failed: unable to read the uploaded file.', PLUGIN_NAME), false, ERROR);
            return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIG_ROUTE);
        }

        $data = $this->decodeAndHealBackupJson($json);

        if (!is_array($data) || !isset($data['configurations']) || !is_array($data['configurations']) || count($data['configurations']) === 0) {
            $jsonError = json_last_error() !== JSON_ERROR_NONE
                ? ' JSON error: ' . json_last_error_msg() . ' (code ' . json_last_error() . ')'
                : ' Structure check failed: missing or empty configurations array.';
            Session::addMessageAfterRedirect(
                __('Restore failed: the backup file has an invalid or unrecognized format.', PLUGIN_NAME) . $jsonError,
                false,
                ERROR
            );
            return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIG_ROUTE);
        }

        // --- 2. Pre-validate all configuration entries before modifying database ---
        $configsTable  = Config::getTable();
        $claimMapTable = ClaimMap::getTable();

        $exportFields = [
            ConfigEntity::ID, ConfigEntity::NAME, ConfigEntity::CONF_DOMAIN,
            ConfigEntity::CONF_ICON, ConfigEntity::CONF_ICON_URL, ConfigEntity::LOGIN_HEADER_TEXT,
            ConfigEntity::ENFORCE_SSO, ConfigEntity::PROXIED,
            ConfigEntity::STRICT, ConfigEntity::DEBUG, ConfigEntity::USER_JIT, ConfigEntity::FORCE_AUTHN,
            ConfigEntity::SYNC_ON_LOGIN, ConfigEntity::REQUEST_TIMEOUT, ConfigEntity::INACTIVITY_TIMEOUT,
            ConfigEntity::SECURITY_WANTMESSAGESSIGNED,
            ConfigEntity::SECURITY_WANTASSERTIONSSIGNED,
            ConfigEntity::SECURITY_WANTASSERTIONSENCRYPTED,
            ConfigEntity::SECURITY_SIGNMETADATA,
            ConfigEntity::SECURITY_WANTNAMEID,
            ConfigEntity::SP_CERTIFICATE, ConfigEntity::SP_KEY_SOURCE, ConfigEntity::SP_KEY, ConfigEntity::SP_NAME_FORMAT,
            ConfigEntity::IDP_ENTITY_ID, ConfigEntity::IDP_SSO_URL, ConfigEntity::IDP_SLO_URL,
            ConfigEntity::IDP_CERTIFICATE, ConfigEntity::AUTHN_CONTEXT, ConfigEntity::AUTHN_COMPARE,
            ConfigEntity::ENCRYPT_NAMEID, ConfigEntity::SIGN_AUTHN, ConfigEntity::SIGN_SLO_REQ,
            ConfigEntity::SIGN_SLO_RES, ConfigEntity::COMPRESS_REQ, ConfigEntity::COMPRESS_RES,
            ConfigEntity::XML_VALIDATION, ConfigEntity::DEST_VALIDATION, ConfigEntity::LOWERCASE_URL,
            ConfigEntity::SCIM_ENABLED, ConfigEntity::SCIM_TOKEN_SOURCE, ConfigEntity::SCIM_ALLOWED_IPS,
            ConfigEntity::SCIM_DEPROVISION, ConfigEntity::SCIM_GROUP_POLICY,
            ConfigEntity::COMMENT, ConfigEntity::IS_ACTIVE,
        ];

        $preparedEntries = [];
        $errors          = [];
        $now             = date('Y-m-d H:i:s');

        foreach ($data['configurations'] as $index => $entry) {
            $prepared = $this->prepareRestoreConfigEntry((int)$index, is_array($entry) ? $entry : [], $now, $exportFields, $errors);
            if ($prepared !== null) {
                $preparedEntries[] = $prepared;
            }
        }

        if (empty($preparedEntries)) {
            foreach ($errors as $err) {
                Session::addMessageAfterRedirect($err, false, ERROR);
            }
            Session::addMessageAfterRedirect(
                __('Restore aborted: no valid IDP configurations were found in the backup file; existing configurations were preserved.', PLUGIN_NAME),
                false,
                ERROR
            );
            return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIG_ROUTE);
        }

        // --- 3. Purge existing data and insert validated configurations ---
        $DB->delete($claimMapTable, ['id' => ['>', 0]]);
        $DB->delete($configsTable,  ['id' => ['>', 0]]);
        Config::clearCache();

        $restoredCount = 0;
        foreach ($preparedEntries as $prepared) {
            if ($this->insertPreparedRestoreEntry($prepared, $configsTable, $errors)) {
                $restoredCount++;
            }
        }
        Config::clearCache();

        // --- 5. Report results ---
        if ($restoredCount > 0) {
            Session::addMessageAfterRedirect(
                sprintf(__('Restore successful: %d IDP configuration(s) restored.', PLUGIN_NAME), $restoredCount)
            );
        }

        foreach ($errors as $err) {
            Session::addMessageAfterRedirect($err, false, ERROR);
        }

        if ($restoredCount === 0) {
            Session::addMessageAfterRedirect(__('Restore completed but no configurations were imported.', PLUGIN_NAME), false, WARNING);
        }

        return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIG_ROUTE);
    }

    /**
     * Decodes backup JSON and applies healing passes for bad encoding/PEM formatting.
     *
     * @param string $json Raw JSON content
     * @return array|null Decoded data array or null on failure
     */
    private function decodeAndHealBackupJson(string $json): ?array
    {
        // Strip UTF-8 BOM if present
        if (str_starts_with($json, "\xEF\xBB\xBF")) {
            $json = substr($json, 3);
        }

        $data = json_decode($json, true);

        // Healing pass 1: strip literal CR bytes (0x0D).
        if (!is_array($data) && json_last_error() !== JSON_ERROR_NONE) {
            $healed = str_replace("\r", '', $json);
            if ($healed !== $json) {
                $data = json_decode($healed, true);
            }
        }

        // Healing pass 2: attempt invalid UTF-8 byte sequence repair and retry
        if (!is_array($data) && json_last_error() !== JSON_ERROR_NONE) {
            $repaired = mb_convert_encoding($json, 'UTF-8', 'UTF-8');
            if ($repaired !== false && $repaired !== $json) {
                $data = json_decode($repaired, true);
            }
        }

        return is_array($data) ? $data : null;
    }

    /**
     * Validates and prepares a single IDP configuration entry prior to destructive DB restore.
     *
     * @param int    $index        Entry index
     * @param array  $entry        Entry data
     * @param string $now          Current datetime string
     * @param array  $exportFields List of fields to copy
     * @param array  $errors       Reference to errors log
     * @return array|null Prepared payload or null when validation fails
     */
    private function prepareRestoreConfigEntry(int $index, array $entry, string $now, array $exportFields, array &$errors): ?array
    {
        if (!isset($entry['config']) || !is_array($entry['config'])) {
            $errors[] = sprintf(__('Entry %d skipped: missing config block.', PLUGIN_NAME), $index);
            return null;
        }

        $cfgData = $entry['config'];
        $origId  = isset($cfgData[ConfigEntity::ID]) ? (int)$cfgData[ConfigEntity::ID] : 0;

        if ($origId <= 0) {
            $errors[] = sprintf(__('Entry %d skipped: missing or invalid id.', PLUGIN_NAME), $index);
            return null;
        }

        // Build insert row; only use known fields that are present in export
        $defaultTpl = ConfigDefaultTpl::template();
        $insertRow = [ConfigEntity::IS_DELETED => 0, ConfigEntity::SCIM_TOKEN_HASH => '', ConfigEntity::CREATE_DATE => $now, ConfigEntity::MOD_DATE => $now];
        foreach ($exportFields as $field) {
            if ($field === ConfigEntity::ID) {
                $insertRow[ConfigEntity::ID] = $origId;
                continue;
            }
            if (array_key_exists($field, $cfgData) && $cfgData[$field] !== null) {
                $insertRow[$field] = $cfgData[$field];
            } elseif (array_key_exists($field, $defaultTpl)) {
                $insertRow[$field] = is_bool($defaultTpl[$field]) ? ($defaultTpl[$field] ? 1 : 0) : $defaultTpl[$field];
            }
        }

        $validationEntity = new ConfigEntity(-1, ['template' => 'post', 'postData' => $insertRow]);
        if (!$validationEntity->isValid()) {
            $errList = implode('; ', array_values($validationEntity->getErrorMessages()));
            $errors[] = sprintf(__('Entry %d (%s) failed validation: %s', PLUGIN_NAME), $index, $cfgData[ConfigEntity::NAME] ?? '?', $errList);
            return null;
        }

        if (!empty($insertRow[ConfigEntity::SP_KEY]) && ($insertRow[ConfigEntity::SP_KEY_SOURCE] ?? 'db') === 'db') {
            $insertRow[ConfigEntity::SP_KEY] = ConfigEntity::encryptPrivateKey((string)$insertRow[ConfigEntity::SP_KEY]);
        }

        $claimMaps = isset($entry['claim_maps']) && is_array($entry['claim_maps'])
            ? $entry['claim_maps']
            : [];

        return [
            'index'      => $index,
            'orig_id'    => $origId,
            'name'       => (string)($cfgData[ConfigEntity::NAME] ?? (string)$origId),
            'insert_row' => $insertRow,
            'claim_maps' => $claimMaps,
        ];
    }

    /**
     * Inserts a pre-validated IDP configuration entry and its claim mappings.
     *
     * @param array  $prepared     Prepared restore payload
     * @param string $configsTable Configuration DB table name
     * @param array  $errors       Reference to errors log
     * @return bool True if successfully inserted
     */
    private function insertPreparedRestoreEntry(array $prepared, string $configsTable, array &$errors): bool
    {
        global $DB;

        if (!$DB->insert($configsTable, $prepared['insert_row'])) {
            $errors[] = sprintf(__('Entry %d (%s) could not be inserted into database.', PLUGIN_NAME), $prepared['index'], $prepared['name']);
            return false;
        }

        $claimMapEntity = new ClaimMapEntity((int)$prepared['orig_id']);
        if (!$claimMapEntity->save($prepared['claim_maps'])) {
            $errors[] = sprintf(__('Config %s restored but claim mappings had validation errors.', PLUGIN_NAME), $prepared['name']);
        }

        return true;
    }

    /**
     * Handles the form calls from the ConfigFormController and loads the
     * configuration item requested from the listing.
     *
     * @param array     $postData $_POST data from form
     * @return Response|RedirectResponse   String containing HTML form with values or redirect into added form.
     */
    public function invokeForm(Request $request): Response|RedirectResponse     // NOSONAR - CRUDE returns by design.
    {
        $action = $request->get('action');
        if ($action === 'forcelogoff') {
            return $this->handleForceLogoffAction($request);
        }
        if ($action === 'generate_cert') {
            return $this->handleGenerateCertAction($request);
        }
        if ($action === 'generate_scim_token') {
            return $this->handleGenerateScimTokenAction($request);
        }

        return $this->dispatchCrudFormAction($request);
    }

    /**
     * Validate POST method, CSRF token, and config UPDATE rights for JSON admin endpoints.
     *
     * @param Request $request Incoming HTTP request.
     * @param string $methodError Translated error message for non-POST requests.
     * @param array $headers JSON response headers.
     * @return Response|null Error JSON response on failure, null when authorized.
     */
    private function authorizeConfigJsonEndpoint(Request $request, string $methodError, array $headers): ?Response
    {
        if (!$request->isMethod('POST')) {
            return new Response((string) json_encode([
                'success' => false,
                'error'   => $methodError,
            ]), Response::HTTP_METHOD_NOT_ALLOWED, $headers);
        }
        if (method_exists(\Session::class, 'validateCSRF') && !\Session::validateCSRF($request->request->all(), true)) {
            return new Response((string) json_encode([
                'success' => false,
                'error'   => __('Security token expired or invalid.', PLUGIN_NAME),
            ]), Response::HTTP_FORBIDDEN, $headers);
        }
        $config = new Config();
        if (!$config->canUpdate()) {
            return new Response((string) json_encode([
                'success' => false,
                'error'   => __('You do not have permission to perform this action.', PLUGIN_NAME),
            ]), Response::HTTP_FORBIDDEN, $headers);
        }

        return null;
    }

    /**
     * Handle POST action to disable a user and force-logoff an active login state session.
     *
     * @param Request $request Incoming HTTP request.
     * @return RedirectResponse Redirect back to the ConfigForm logging tab.
     */
    private function handleForceLogoffAction(Request $request): RedirectResponse
    {
        if (!$request->isMethod('POST')) {
            Session::addMessageAfterRedirect(__('Invalid request method for force logoff.', PLUGIN_NAME), false, ERROR);
            return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIGFORM_ROUTE);
        }
        if (method_exists(\Session::class, 'validateCSRF') && !\Session::validateCSRF($request->request->all())) {
            Session::addMessageAfterRedirect(__('Security token expired or invalid.', PLUGIN_NAME), false, ERROR);
            return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIGFORM_ROUTE);
        }
        $config = new Config();
        if (!$config->canUpdate()) {
            Session::addMessageAfterRedirect(__('You do not have permission to perform this action.', PLUGIN_NAME), false, ERROR);
            return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIGFORM_ROUTE);
        }

        $stateId = (int) $request->request->get('state_id');
        if ($stateId > 0) {
            $this->terminateLoginStateAndDisableUser($stateId);
        }

        $idpId = !empty($request->request->get('id')) ? (int) $request->request->get('id') : -1;
        return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIGFORM_ROUTE . '?id=' . $idpId . '#logging');
    }

    /**
     * Disable the GLPI user linked to a LoginState row (if any) and mark the state PHASE_FORCE_LOG.
     *
     * @param int $stateId LoginState record ID.
     * @return void
     */
    private function terminateLoginStateAndDisableUser(int $stateId): void
    {
        $loginState = new LoginState();
        if (!$loginState->getFromID($stateId)) {
            Session::addMessageAfterRedirect(__('Login state session not found.', PLUGIN_NAME), false, ERROR);
            return;
        }

        $userId = $loginState->getUserId();
        if ($userId > 0) {
            $user = new \User();
            if ($user->getFromDB($userId)) {
                $user->update([SamlUser::USERID => $userId, SamlUser::ACTIVE => 0]);
            }
        }
        $loginState->setPhase(LoginState::PHASE_FORCE_LOG);
        Session::addMessageAfterRedirect(__('User disabled and session forced logoff.', PLUGIN_NAME));
    }

    /**
     * Handle AJAX POST action to generate a self-signed SP certificate/private-key pair.
     *
     * @param Request $request Incoming HTTP request.
     * @return Response JSON response containing PEM pair or error message.
     */
    private function handleGenerateCertAction(Request $request): Response
    {
        $jsonHeaders = ['Content-Type' => 'application/json'];
        $authError = $this->authorizeConfigJsonEndpoint(
            $request,
            __('Invalid request method for certificate generation.', PLUGIN_NAME),
            $jsonHeaders
        );
        if ($authError !== null) {
            return $authError;
        }

        $commonName = trim((string) $request->request->get('common_name', ''));
        $validYears = (int) $request->request->get('valid_years', 3);
        $validDays  = $validYears > 0 ? ($validYears * 365) : 1095;
        if ($request->request->has('valid_days') && (int) $request->request->get('valid_days') > 0) {
            $validDays = (int) $request->request->get('valid_days');
        }
        $keyType   = strtoupper(trim((string) $request->request->get('key_type', 'RSA')));
        $keyBits   = (int) $request->request->get('key_bits', 2048);
        $curveName = trim((string) $request->request->get('curve_name', 'prime256v1'));
        $digestAlg = strtolower(trim((string) $request->request->get('digest_alg', 'sha256')));

        if ($keyType === 'RSA' && $keyBits < 2048) {
            return new Response((string) json_encode([
                'success' => false,
                'error'   => __('RSA key length must be at least 2048 bits to comply with security standards.', PLUGIN_NAME),
            ]), Response::HTTP_BAD_REQUEST, $jsonHeaders);
        }

        $pair = ConfigEntity::generateSelfSignedCertificate($commonName, $validDays, $keyType, $keyBits, $curveName, $digestAlg);
        if ($pair === false) {
            return new Response((string) json_encode([
                'success' => false,
                'error'   => __('OpenSSL certificate generation failed or OpenSSL is not available.', PLUGIN_NAME),
            ]), Response::HTTP_INTERNAL_SERVER_ERROR, $jsonHeaders);
        }

        return new Response((string) json_encode([
            'success'     => true,
            'certificate' => $pair['certificate'],
            'private_key' => $pair['private_key'],
            'message'     => __('New self-signed certificate and private key generated successfully.', PLUGIN_NAME),
        ]), Response::HTTP_OK, $jsonHeaders);
    }

    /**
     * Handle AJAX POST action to generate/rotate a per-IdP SCIM Bearer token digest.
     *
     * @param Request $request Incoming HTTP request.
     * @return Response JSON response containing one-time plaintext token or error message.
     */
    private function handleGenerateScimTokenAction(Request $request): Response
    {
        $jsonHeaders = [
            'Content-Type'  => 'application/json',
            'Cache-Control' => 'no-store, no-cache, must-revalidate',
        ];
        $authError = $this->authorizeConfigJsonEndpoint(
            $request,
            __('Invalid request method for SCIM token generation.', PLUGIN_NAME),
            $jsonHeaders
        );
        if ($authError !== null) {
            return $authError;
        }

        $config = new Config();
        $targetId = (int) $request->request->get('id', -1);
        if (
            $targetId <= 0 ||
            !$config->getFromDB($targetId) ||
            (int) ($config->fields[ConfigEntity::IS_DELETED] ?? 0) === 1
        ) {
            return new Response((string) json_encode([
                'success' => false,
                'error'   => __('Save the Identity Provider configuration before generating a SCIM Bearer token.', PLUGIN_NAME),
            ]), Response::HTTP_BAD_REQUEST, $jsonHeaders);
        }

        $generated = ScimAuthenticator::generateToken();
        global $DB;
        $updated = $DB->update(
            Config::getTable(),
            [
                ConfigEntity::SCIM_TOKEN_HASH   => $generated['hash'],
                ConfigEntity::SCIM_TOKEN_SOURCE => 'db',
            ],
            [ConfigEntity::ID => $targetId]
        );
        if (!$updated) {
            return new Response((string) json_encode([
                'success' => false,
                'error'   => __('Failed to persist generated SCIM Bearer token digest.', PLUGIN_NAME),
            ]), Response::HTTP_INTERNAL_SERVER_ERROR, $jsonHeaders);
        }

        ConfigEntity::clearCache();
        Config::clearCache();

        $actorId = (int) \Session::getLoginUserID();
        Toolbox::logInFile(
            PLUGIN_SAMLSSO_LOGEVENTS,
            sprintf("SCIM Bearer token generated or rotated for IdP #%d by user #%d\n", $targetId, $actorId)
        );

        return new Response((string) json_encode([
            'success' => true,
            'token'   => $generated['plaintext'],
            'message' => __('New SCIM Bearer token generated. Copy it now; it cannot be displayed again.', PLUGIN_NAME),
        ]), Response::HTTP_OK, $jsonHeaders);
    }

    /**
     * Dispatch standard show/create/update/delete CRUD operations for an IdP configuration form.
     *
     * @param Request $request Incoming HTTP request.
     * @return Response|RedirectResponse Rendered form or redirect response.
     */
    private function dispatchCrudFormAction(Request $request): Response|RedirectResponse
    {
        $inputBag = $request->getPayload();
        $id = !empty($request->get('id')) ? (int) $request->get('id') : -1;
        $requestedTpl = $request->get('template');
        $options = [
            'template' => (is_string($requestedTpl) && $requestedTpl !== '' && ctype_alpha($requestedTpl)) ? $requestedTpl : 'default',
            'search'   => (string) $request->get('search', ''),
            'page'     => !empty($request->get('page')) ? (int) $request->get('page') : 1,
        ];

        if (!$inputBag->has('update') && !$inputBag->has('delete')) {
            Session::checkRight('config', READ);
            $this->displayUIHeader();
            return $this->showForm($id, $options);
        }

        if ($inputBag->has('update') && $id == -1) {
            Session::checkRight('config', UPDATE);
            $this->displayUIHeader();
            return $this->addSamlConfig($inputBag->getIterator());
        }

        if ($inputBag->has('update') && $id > 0) {
            Session::checkRight('config', UPDATE);
            return $this->updateSamlConfig($inputBag->getIterator());
        }

        if ($inputBag->has('delete') && $id > 0) {
            Session::checkRight('config', UPDATE);
            return $this->deleteSamlConfig($inputBag->getIterator());
        }

        $this->displayUIHeader();
        return new Response('No valid instructions received');
    }


    /**
     * Populates the GLPI headers (UI)
     * Might cause headers to be send prematurely as Html::header contains echo operations.
     *
     * @param void
     * @return void
     */
    private function displayUIHeader()
    {
        Html::header(Config::getTypeName().' entities',                         // Title for browser tab
                     SamlSsoController::CONFIG_ROUTE,
                     SamlSsoController::CONFIG_PNAME,
                     Config::class);
    }


    /**
     * Add new phpSaml configuration
     *
     * @param array     $postData $_POST data from form
     * @return          Response|RedirectResponse          String containing HTML form with values or redirect into added form.
     */
    public function addSamlConfig(\ArrayIterator $postData): Response|RedirectResponse
    {
        // Populate configEntity using post;
        $configEntity = new ConfigEntity(-1, ['template' => 'post', 'postData' => $postData]);
        
        // Populate and validate claim mappings
        $claimMap = isset($postData['claim_map']) && is_array($postData['claim_map']) ? $postData['claim_map'] : [];
        $claimMapEntity = new ClaimMapEntity(-1);
        $claimMapValid = $claimMapEntity->validate($claimMap);

        // Validate configEntity and claim mappings
        if($configEntity->isValid() && $claimMapValid){
            // Get the normalized database fields
            $fields = $configEntity->getDBFields([ConfigEntity::ID, ConfigEntity::CREATE_DATE, ConfigEntity::MOD_DATE]);
            // Get instance of SamlConfig for db update.
            $config = new Config();
            // Perform database insert using db fields.
            $id = $config->add($fields);
            if ($id) {
                // Save claim mappings if present in postData
                $claimMapEntity = new ClaimMapEntity((int)$id);
                $claimMapEntity->save($claimMap);
                // Leave succes message for user and redirect
                Session::addMessageAfterRedirect(__('Successfully added new samlSSO configuration.', PLUGIN_NAME));
                return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIGFORM_ROUTE . '?id=' . $id);
            } else {
                // Leave error message for user and regenerate form with values
                Session::addMessageAfterRedirect(__('Unable to add new samlSSO configuration, please review error logging', PLUGIN_NAME));
                return new Response( $this->generateForm($configEntity) );
            }
        }else{
            // Leave error message for user and regenerate form with values
            Session::addMessageAfterRedirect(__('Configuration invalid, please correct all ⭕ errors first', PLUGIN_NAME));
            return new Response( $this->generateForm($configEntity) );
        }
    }

    /**
     * Update phpSaml configuration
     *
     * @param int   $id of configuration to update
     * @param array $postData $_POST data from form
     * @return      Response|RedirectResponse -
     */
    public function updateSamlConfig(\ArrayIterator $postData): Response|RedirectResponse
    {
        // Populate configEntity using post;
        $configEntity = new ConfigEntity(-1, ['template' => 'post', 'postData' => $postData]);
        
        // Populate and validate claim mappings
        $claimMap = isset($postData['claim_map']) && is_array($postData['claim_map']) ? $postData['claim_map'] : [];
        $claimMapEntity = new ClaimMapEntity((int)$postData['id']);
        $claimMapValid = $claimMapEntity->validate($claimMap);

        // Validate configEntity and claim mappings
        if($configEntity->isValid() && $claimMapValid){
            // Get the normalized database fields
            $fields = $configEntity->getDBFields([ConfigEntity::CREATE_DATE, ConfigEntity::IS_DELETED]);
            // Add the cross site request forgery token to the fields if present (legacy GLPI)
            if (isset($postData['_glpi_csrf_token'])) {
                $fields['_glpi_csrf_token'] = $postData['_glpi_csrf_token'];
            }
            // Get instance of SamlConfig for db update.
            $config = new Config();
            // Perform database update using fields.
            if($config->canUpdate()       &&
               $config->update($fields) ){
                // Save claim mappings
                $claimMapEntity->save($claimMap);
                // Leave a success message for the user and redirect using ID.
                Session::addMessageAfterRedirect(__('Configuration updated successfully', PLUGIN_NAME));
                return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIGFORM_ROUTE . '?id=' . $postData['id']);
            } else {
                // Leave a failed message
                Session::addMessageAfterRedirect(__('Configuration update failed, check your update rights or error logging', PLUGIN_NAME));
                return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIGFORM_ROUTE . '?id=' . $postData['id']);
            }
        }else{
            // Leave an error message and reload the form with provided values and errors
            Session::addMessageAfterRedirect(__('Configuration invalid, please correct all ⭕ errors first', PLUGIN_NAME));
            $this->displayUIHeader();
            return new Response($this->generateForm($configEntity));
        }
    }

    /**
     * Add new phpSaml configuration
     *
     * @param array $postData $_POST data from form
     * @return      Response|RedirectResponse
     */
    public function deleteSamlConfig(\ArrayIterator $postData): RedirectResponse
    {
        // Get SamlConfig object for deletion
        $config = new Config();
        // Validate user has the rights to delete then delete
        if($config->canPurge()  &&
           $config->delete((array) $postData)){
            ScimLink::deleteAllForConfig((int) ($postData['id'] ?? 0));
            // Leave success message and redirect
            Session::addMessageAfterRedirect(__('Configuration deleted successfully', PLUGIN_NAME));
            return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIG_ROUTE);
        } else {
            // Leave fail message and redirect back to config.
            Session::addMessageAfterRedirect(__('Not allowed or error deleting SAML configuration!', PLUGIN_NAME));
            return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIG_ROUTE . '?id=' . $postData['id']);
        }
    }

    /**
     * Figures out what form to show
     *
     * @param  integer  $id       ID the configuration item to show
     * @param  array    $options  Options
     * @return Response
     */
    public function showForm(int $id, array $options = []): Response|RedirectResponse
    {
        if($id === -1 || $id > 0){
            // Generate form using a template
            return new Response($this->generateForm(new ConfigEntity($id, $options), $options));
        }else{
            // Invalid id used redirect back to configuration listing
            Session::addMessageAfterRedirect(__('Invalid request, redirecting back', PLUGIN_NAME), false, ERROR);
            return new RedirectResponse(samlsso_webdir() . SamlSsoController::CONFIG_ROUTE);
        }
    }

    /**
     * Determines whether validation errors or advisory warnings exist in each tab
     * and maps warning indicators to the respective configuration tab headers.
     *
     * @param  array<string, mixed> $fields Configuration fields from ConfigEntity::getFields().
     * @return array<string, string> Associative array of tab warning symbols (e.g. '⚠️' or '').
     * @see https://github.com/DonutsNL/samlsso/issues/185
     * @since 1.0.0
     */
    public function getTabWarnings(array $fields): array
    {
        $tabFields = [
            'general_warning'  => [
                ConfigEntity::NAME,
                ConfigEntity::CONF_DOMAIN,
                ConfigEntity::CONF_ICON,
                ConfigEntity::CONF_ICON_URL,
                ConfigEntity::LOGIN_HEADER_TEXT,
                ConfigEntity::COMMENT,
                ConfigEntity::IS_ACTIVE,
                ConfigEntity::DEBUG,
            ],
            'transit_warning'  => [
                ConfigEntity::COMPRESS_REQ,
                ConfigEntity::COMPRESS_RES,
                ConfigEntity::PROXIED,
                ConfigEntity::XML_VALIDATION,
                ConfigEntity::DEST_VALIDATION,
                ConfigEntity::LOWERCASE_URL,
            ],
            'provider_warning' => [
                ConfigEntity::SP_CERTIFICATE,
                ConfigEntity::SP_KEY_SOURCE,
                ConfigEntity::SP_KEY,
                ConfigEntity::SP_NAME_FORMAT,
            ],
            'idp_warning'      => [
                ConfigEntity::IDP_ENTITY_ID,
                ConfigEntity::IDP_SSO_URL,
                ConfigEntity::IDP_SLO_URL,
                ConfigEntity::IDP_CERTIFICATE,
                ConfigEntity::AUTHN_CONTEXT,
                ConfigEntity::AUTHN_COMPARE,
            ],
            'security_warning' => [
                ConfigEntity::ENFORCE_SSO,
                ConfigEntity::REQUEST_TIMEOUT,
                ConfigEntity::INACTIVITY_TIMEOUT,
                ConfigEntity::STRICT,
                ConfigEntity::USER_JIT,
                ConfigEntity::SYNC_ON_LOGIN,
                ConfigEntity::ENCRYPT_NAMEID,
                ConfigEntity::SIGN_AUTHN,
                ConfigEntity::FORCE_AUTHN,
                ConfigEntity::SIGN_SLO_REQ,
                ConfigEntity::SIGN_SLO_RES,
                ConfigEntity::SECURITY_WANTMESSAGESSIGNED,
                ConfigEntity::SECURITY_WANTASSERTIONSSIGNED,
                ConfigEntity::SECURITY_WANTASSERTIONSENCRYPTED,
                ConfigEntity::SECURITY_SIGNMETADATA,
                ConfigEntity::SECURITY_WANTNAMEID,
            ],
            'scim_warning'     => [
                ConfigEntity::SCIM_ENABLED,
                ConfigEntity::SCIM_TOKEN_HASH,
                ConfigEntity::SCIM_TOKEN_SOURCE,
                ConfigEntity::SCIM_ALLOWED_IPS,
                ConfigEntity::SCIM_DEPROVISION,
                ConfigEntity::SCIM_GROUP_POLICY,
            ],
        ];

        $warnings = [];
        foreach ($tabFields as $tab => $entityFields) {
            $warnings[$tab] = '';
            foreach ($entityFields as $field) {
                if (!isset($fields[$field]) || !is_array($fields[$field])) {
                    continue;
                }

                $err = (string)($fields[$field]['errors'] ?? '');
                $eval = (string)($fields[$field]['eval'] ?? '');

                if ($eval === ConfigItem::INVALID) {
                    $warnings[$tab] = '⚠️';
                } elseif (!empty($err)) {
                    if (str_contains($err, '⚠️') || str_contains($err, '⭕') || str_contains($err, '❌')) {
                        $warnings[$tab] = '⚠️';
                    } elseif (!str_contains($err, '✅')) {
                        $warnings[$tab] = '⚠️';
                    }
                }

                if (!empty($fields[$field]['validate']['validations']['validTo']) ||
                    !empty($fields[$field]['validate']['validations']['validFrom'])) {
                    $warnings[$tab] = '⚠️';
                }
            }
        }

        return $warnings;
    }

    /**
     * Generates the HTML for the config form using the GLPI
     * template renderer.
     *
     * @param ConfigEntity $configEntity    Field values to populate in form
     * @return string ConfigForm            HTML
     * @since                               1.0.0
     * @see https://codeberg.org/QuinQuies/glpisaml/issues/17
     */
    private function generateForm(ConfigEntity $configEntity, array $options = [])
    {
        global $CFG_GLPI;

        $fields = $configEntity->getFields();
        $fields[ConfigEntity::AUTHN_CONTEXT][ConfigItem::VALUE] = $configEntity->getRequestedAuthnContextArray();

        $idpId = is_numeric($fields[ConfigEntity::ID]['value']) ? (int) $fields[ConfigEntity::ID]['value'] : -1;
        $fields = $this->normalizeFieldSubkeys($fields);

        $search = (string) ($options['search'] ?? '');
        $page   = !empty($options['page']) ? (int) $options['page'] : 1;

        $tplVars = array_merge(
            $this->getTabWarnings($fields),
            $this->resolveClaimMappingViewData($idpId),
            $this->resolveLoggingViewData($idpId, $search, $page),
            $this->resolveCredentialDisplayState($fields, (string) ($CFG_GLPI['url_base'] ?? '')),
            $this->buildConfigFormOptionLists(),
            [
                'scimUrl'                   => $idpId > 0 ? (samlsso_webdir() . SamlSsoController::SCIM_ROUTE . '/' . $idpId) : '',
                'scim_linked_users_count'   => $idpId > 0 ? ScimLink::countForConfigAndType($idpId, ScimLink::TYPE_USER) : 0,
                'scim_linked_groups_count'  => $idpId > 0 ? ScimLink::countForConfigAndType($idpId, ScimLink::TYPE_GROUP) : 0,
                'scim_last_sync'            => $idpId > 0 ? (ScimLink::getLastSyncForConfig($idpId) ?? '') : '',
                'saml_xml_structure'        => $fields[ConfigEntity::SAML_XML_STRUCTURE]['value'] ?? '',
                'plugin'                    => PLUGIN_NAME,
                'close_form'                => Html::closeForm(false),
                'csrf_token'                => method_exists(\Session::class, 'getNewCSRFToken') ? \Session::getNewCSRFToken() : '',
                'currentUserId'             => (int) \Session::getLoginUserID(),
                'currentUsername'           => (string) ($_SESSION['glpiname'] ?? ''),
                'glpi_rootdoc'              => samlsso_webdir() . SamlSsoController::CONFIGFORM_ROUTE . '?id=' . $fields[ConfigEntity::ID][ConfigItem::VALUE],
                'glpi_tpl_macro'            => '/components/form/fields_macros.html.twig',
                'inputfields'               => $fields,
                'buttonsHiddenWarn'         => (bool) $configEntity->getConfigDomain(),
                'entityID'                  => $CFG_GLPI['url_base'] . '/',
                'acsUrl'                    => samlsso_webdir() . SamlSsoController::ACS_ROUTE . '/' . $fields[ConfigEntity::ID][ConfigItem::VALUE],
                'metaUrl'                   => samlsso_webdir() . SamlSsoController::META_ROUTE . '/' . $fields[ConfigEntity::ID][ConfigItem::VALUE],
                'sloUrl'                    => samlsso_webdir() . SamlSsoController::SLO_ROUTE . '/' . $fields[ConfigEntity::ID][ConfigItem::VALUE],
            ]
        );

        return TemplateRenderer::getInstance()->render('@samlsso/configForm.html.twig', $tplVars);
    }

    /**
     * Resolve claim mapping rows, validation errors, presets, and observed claim warnings.
     *
     * @param int $idpId IdP configuration ID.
     * @return array Associative array of claim-mapping template variables.
     */
    private function resolveClaimMappingViewData(int $idpId): array
    {
        $claimMapEntity = new ClaimMapEntity($idpId);
        $claimErrors    = [];
        $claimMapValid  = true;

        if (isset($_POST['claim_map']) && is_array($_POST['claim_map'])) {
            $claimMappings = $_POST['claim_map'];
            $claimMapValid = $claimMapEntity->validate($claimMappings);
            $claimErrors   = $claimMapEntity->getErrors();
            $claimMappings = ClaimMapEntity::sortMappings($claimMappings);
        } else {
            $claimMappings = $claimMapEntity->getMappings();
        }

        $observedClaims   = $claimMapEntity->getObservedClaims();
        $claimWarnings    = [];
        $hasClaimWarning  = false;
        $unusedRuleFields = [];
        if ($idpId > 0) {
            $unusedRuleFields = $claimMapEntity->getUnusedRuleFields();
            $hasClaimWarning  = !empty($unusedRuleFields);
            foreach ($claimMappings as $index => $mapping) {
                $claim = $mapping[ClaimMap::SAML_CLAIM] ?? '';
                if (!empty($observedClaims) && $claim !== '' && !in_array($claim, $observedClaims, true)) {
                    $claimWarnings[$index] = __('This claim key has not been observed in any SAML responses yet.', PLUGIN_NAME);
                    $hasClaimWarning = true;
                }
            }
        }

        return [
            'claim_mappings'      => $claimMappings,
            'claim_errors'        => $claimErrors,
            'observed_claims'     => $observedClaims,
            'mapping_presets'     => ClaimMapEntity::getPresets(),
            'allowed_user_fields' => ClaimMapItem::ALLOWED_USER_FIELDS,
            'allowed_rule_fields' => ClaimMapItem::ALLOWED_RULE_FIELDS,
            'claim_warnings'      => $claimWarnings,
            'unused_rule_fields'  => $unusedRuleFields,
            'claim_tab_warning'   => ($hasClaimWarning || !$claimMapValid) ? '⚠️' : '',
        ];
    }

    /**
     * Fetch paginated authentication logging entries for the Logging tab.
     *
     * @param int $idpId IdP configuration ID.
     * @param string $search Optional search term.
     * @param int $page Requested page number.
     * @param int $limit Entries per page.
     * @return array Associative array of logging template variables.
     */
    private function resolveLoggingViewData(int $idpId, string $search, int $page, int $limit = 20): array
    {
        if ($idpId <= 0) {
            return [
                'loggingfields'       => [],
                'logging_search'      => $search,
                'logging_page'        => 1,
                'logging_total_pages' => 1,
                'logging_total_count' => 0,
            ];
        }

        $totalCount = LoginState::getLoggingEntriesCount($idpId, $search);
        $totalPages = (int) max(1, ceil($totalCount / $limit));
        $clampedPage = min($page, $totalPages);

        return [
            'loggingfields'       => LoginState::getLoggingEntries($idpId, $search, $clampedPage, $limit),
            'logging_search'      => $search,
            'logging_page'        => $clampedPage,
            'logging_total_pages' => $totalPages,
            'logging_total_count' => $totalCount,
        ];
    }

    /**
     * Default optional field sub-keys so Twig strict_variables renders cleanly.
     *
     * @param array $fields Configuration fields array.
     * @return array Normalized fields array.
     */
    private function normalizeFieldSubkeys(array $fields): array
    {
        $requiredSubkeys = [
            ConfigItem::ERRORS,
            ConfigItem::FORMTITLE,
            ConfigItem::FORMEXPLAIN,
            ConfigItem::VALIDATE,
            ConfigItem::FIELD,
            ConfigItem::VALUE,
        ];
        foreach ($fields as $fkey => $fval) {
            if (!is_array($fval)) {
                continue;
            }
            foreach ($requiredSubkeys as $skey) {
                if (!array_key_exists($skey, $fval)) {
                    $fields[$fkey][$skey] = '';
                }
            }
        }
        return $fields;
    }

    /**
     * Compute certificate/OpenSSL UI flags and scrub DB-stored or privileged secrets from form output.
     *
     * @param array $fields Normalized config fields array (scrubbed in-place).
     * @param string $urlBase GLPI base URL for default CN inference.
     * @return array Credential display state variables for Twig.
     */
    private function resolveCredentialDisplayState(array &$fields, string $urlBase): array
    {
        $spCertVal = (string) ($fields[ConfigEntity::SP_CERTIFICATE][ConfigItem::VALUE] ?? '');
        $isTestCert = empty(trim($spCertVal))
            || str_contains($spCertVal, 'withlove.from.donuts.nl')
            || (($fields[ConfigEntity::SP_CERTIFICATE]['validate']['subject']['CN'] ?? '') === 'withlove.from.donuts.nl');

        $spKeySource = (string) ($fields[ConfigEntity::SP_KEY_SOURCE][ConfigItem::VALUE] ?? 'db');
        $hasStoredSpKey = $spKeySource === 'db' && !empty($fields[ConfigEntity::SP_KEY][ConfigItem::VALUE]);
        if ($spKeySource === 'db' || !Session::haveRight('config', UPDATE)) {
            $fields[ConfigEntity::SP_KEY][ConfigItem::VALUE] = '';
        }

        $scimTokenSource = (string) ($fields[ConfigEntity::SCIM_TOKEN_SOURCE][ConfigItem::VALUE] ?? 'db');
        $rawScimHash = (string) ($fields[ConfigEntity::SCIM_TOKEN_HASH][ConfigItem::VALUE] ?? '');
        $hasStoredScimToken = $scimTokenSource === 'db' && preg_match('/^[a-fA-F0-9]{64}$/', $rawScimHash) === 1;
        if ($scimTokenSource === 'db' || !Session::haveRight('config', UPDATE)) {
            $fields[ConfigEntity::SCIM_TOKEN_HASH][ConfigItem::VALUE] = '';
        }

        return [
            'is_test_certificate'   => $isTestCert,
            'has_stored_sp_key'     => $hasStoredSpKey,
            'has_stored_scim_token' => $hasStoredScimToken,
            'openssl_available'     => extension_loaded('openssl') && function_exists('openssl_pkey_new'),
            'default_cert_cn'       => !empty($urlBase) ? ((string) parse_url($urlBase, PHP_URL_HOST) ?: 'glpi-saml-sp') : 'glpi-saml-sp',
        ];
    }

    /**
     * Build translated select-option lists used across the configuration form tabs.
     *
     * @return array Associative array of dropdown option arrays.
     */
    private function buildConfigFormOptionLists(): array
    {
        return [
            'inputOptionsBool' => [
                1 => __('Yes', PLUGIN_NAME),
                0 => __('No', PLUGIN_NAME),
            ],
            'inputOptionsNameFormat' => [
                Saml2Const::NAMEID_UNSPECIFIED   => __('Unspecified', PLUGIN_NAME),
                Saml2Const::NAMEID_EMAIL_ADDRESS => __('Email Address', PLUGIN_NAME),
                Saml2Const::NAMEID_TRANSIENT     => __('Transient', PLUGIN_NAME),
                Saml2Const::NAMEID_PERSISTENT    => __('Persistent', PLUGIN_NAME),
            ],
            'inputOptionsKeySource' => [
                'db'     => __('Database (legacy)', PLUGIN_NAME),
                'file'   => __('Secure File Path', PLUGIN_NAME),
                'env'    => __('Environment Variable', PLUGIN_NAME),
                'define' => __('PHP Define / Constant', PLUGIN_NAME),
            ],
            'inputOptionsAuthnContext' => [
                'PasswordProtectedTransport' => __('PasswordProtectedTransport', PLUGIN_NAME),
                'Password'                   => __('Password', PLUGIN_NAME),
                'X509'                       => __('X509', PLUGIN_NAME),
                'none'                       => __('none', PLUGIN_NAME),
            ],
            'inputOptionsAuthnCompare' => [
                'exact'   => __('Exact', PLUGIN_NAME),
                'minimum' => __('Minimum', PLUGIN_NAME),
                'maximum' => __('Maximum', PLUGIN_NAME),
                'better'  => __('Better', PLUGIN_NAME),
            ],
            'inputOptionsScimTokenSource' => [
                'db'     => __('Database (SHA-256 Digest)', PLUGIN_NAME),
                'env'    => __('Environment Variable', PLUGIN_NAME),
                'define' => __('PHP Define / Constant', PLUGIN_NAME),
            ],
            'inputOptionsScimDeprovision' => [
                'disable'  => __('Disable User & Force Logoff', PLUGIN_NAME),
                'trashbin' => __('Move to Trashbin, Disable & Force Logoff', PLUGIN_NAME),
            ],
            'inputOptionsScimGroupPolicy' => [
                'create_scoped' => __('Create & Manage Groups', PLUGIN_NAME),
                'link_existing' => __('Link Existing GLPI Groups Only', PLUGIN_NAME),
                'disabled'      => __('Disabled (Users Only)', PLUGIN_NAME),
            ],
            'inputOptionsIcons' => self::getAvailableIcons(),
        ];
    }

    /**
     * Parses the installed FontAwesome CSS file to extract all available icons.
     *
     * @return array Array of icon classes mapping to their friendly/readable names.
     */
    protected static function getAvailableIcons(): array
    {
        $defaultIcons = [
            'fa-brands fa-microsoft'       => __('Microsoft', PLUGIN_NAME),
            'fa-brands fa-google'          => __('Google', PLUGIN_NAME),
            'fa-brands fa-github'          => __('GitHub', PLUGIN_NAME),
            'fa-brands fa-apple'           => __('Apple', PLUGIN_NAME),
            'fa-brands fa-openid'          => __('OpenID', PLUGIN_NAME),
            'fa-solid fa-key'              => __('Key', PLUGIN_NAME),
            'fa-solid fa-shield-halved'    => __('Shield', PLUGIN_NAME),
            'fa-solid fa-lock'             => __('Lock', PLUGIN_NAME),
            'fa-solid fa-user-lock'        => __('User Lock', PLUGIN_NAME),
            'fa-solid fa-cloud'            => __('Cloud / Azure', PLUGIN_NAME),
            'fa-solid fa-right-to-bracket' => __('Sign In', PLUGIN_NAME),
        ];

        $cssPath = GLPI_ROOT . '/public/lib/base.css';
        if (!file_exists($cssPath)) {
            return $defaultIcons;
        }

        $content = file_get_contents($cssPath);
        if ($content === false) {
            return $defaultIcons;
        }

        $brandsStartOffset = strpos($content, '.fa-brands {');

        if (!preg_match_all('/^\.fa-([a-z0-9-]+)/m', $content, $matches, PREG_OFFSET_CAPTURE)) {
            return $defaultIcons;
        }

        $icons = [];
        $ignoredNames = [
            'solid', 'regular', 'brands', 'classic', 'fw', 'ul', 'li', 'border', 'inverse',
            'pull-left', 'pull-right', 'beat', 'bounce', 'fade', 'beat-fade', 'flip', 'shake',
            'spin', 'spin-reverse', 'pulse', 'spin-pulse', 'rotate-90', 'rotate-180',
            'rotate-270', 'flip-horizontal', 'flip-vertical', 'flip-both', 'rotate-by',
            'stack', 'stack-1x', 'stack-2x', 'sr-only', 'sr-only-focusable'
        ];

        foreach ($matches[1] as $match) {
            $name = $match[0];
            $offset = $match[1];

            if (in_array($name, $ignoredNames, true)) {
                continue;
            }

            if (preg_match('/^\d+x$/', $name) || preg_match('/^\d+xs$/', $name) || preg_match('/^\d+xl$/', $name) ||
                preg_match('/^(xs|sm|lg|xl)$/', $name) || preg_match('/^\d+$/', $name)
            ) {
                continue;
            }

            $readableName = ucwords(str_replace('-', ' ', $name));

            if ($brandsStartOffset !== false && $offset >= $brandsStartOffset) {
                $icons["fa-brands fa-$name"] = $readableName;
            } else {
                $icons["fa-solid fa-$name"] = $readableName;
                $icons["fa-regular fa-$name"] = $readableName;
            }
        }

        if (count($icons) > 0) {
            asort($icons);
            return $icons;
        }

        return $defaultIcons;
    }
}
