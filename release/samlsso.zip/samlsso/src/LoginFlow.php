<?php

declare(strict_types=1);
/**
 *  ------------------------------------------------------------------------
 *  Samlsso
 *
 *  Samlsso was inspired by the initial work of Derrick Smith's
 *  PhpSaml. This project's intend is to address some structural issues
 *  caused by the gradual development of GLPI and the broad amount of
 *  wishes expressed by the community.
 *
 *  Copyright (C) 2024 by Chris Gralike
 *  ------------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of Samlsso project.
 *
 * Samlsso plugin is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Samlsso is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Samlsso. If not, see <http://www.gnu.org/licenses/> or
 * https://choosealicense.com/licenses/gpl-3.0/
 *
 * ------------------------------------------------------------------------
 *
 *  @package    Samlsso
 *  @version    1.3.2
 *  @author     Chris Gralike
 *  @copyright  Copyright (c) 2024 by Chris Gralike
 *  @license    GPLv3+
 *  @see        https://github.com/DonutsNL/samlsso/readme.md
 *  @link       https://github.com/DonutsNL/samlsso
 * ------------------------------------------------------------------------
 *
 * The concern this class addresses is added because we want to add support
 * for multiple idp's. Deciding what idp to use might involve more complex
 * algorithms then we used (1:1) in the previous version of phpSaml. These
 * can then be implemented here.
 *
 **/

namespace GlpiPlugin\Samlsso;

use Html;
use Session;
use Toolbox;
use Throwable;
use Migration;
use GlpiPlugin\Samlsso\Compat\LoginFlowCompat;
use OneLogin\Saml2\Auth as samlAuth;
use OneLogin\Saml2\Response;
use Glpi\Application\View\TemplateRenderer;
use GlpiPlugin\Samlsso\Config;
use GlpiPlugin\Samlsso\LoginState;
use GlpiPlugin\Samlsso\Config\ConfigEntity;
use GlpiPlugin\Samlsso\Controller\SamlSsoController;
use GlpiPlugin\Samlsso\LoginFlow\User;
use GlpiPlugin\Samlsso\LoginFlow\Auth as GlpiAuth;

// Version-selected compatibility layer (GLPI 11 untyped / GLPI 12 typed core
// properties). Must be required before the class below extends LoginFlowCompat.
require_once __DIR__ . '/compat.php';

/**
 * This object brings it all together. It is responsible to handle the
 * main logic concerned with the Saml login and logout flows.
 * it will call upon various supporting objects to perform its tasks.
 *
 * $dohistory (true) and $rightname ('config') are carried by LoginFlowCompat,
 * version-typed for GLPI 11 and GLPI 12; redeclaring them here would be a
 * fatal type-invariance error on one of the two cores.
 */
class LoginFlow extends LoginFlowCompat
{
    // Database fields
    public const ID                 =   'id';
    public const DEBUG              =   'debug';
    public const ENFORCED           =   'enforced';
    public const ENFORCED_IDP       =   'forcedIdp';
    public const EN_GETTER_LOGIN    =   'enableGetterLogin';
    public const EN_GLPI_LOGIN      =   'enableGlpiLogin';
    public const EN_SAML_BUTTONS    =   'enableSamlButtons';
    public const EN_USERNAME_LOGIN  =   'enableUsername';
    public const CUSTOM_LOGIN_TPL   =   'useCustomLoginTemplate';
    public const BYPASS_VAR         =   'byPassVar';
    public const BYPASS_STR         =   'byPassString';
    public const EN_IDP_LOGOUT      =   'enableIdpLogout';
    public const ENF_AUTH_AFTER     =   'enforceReAuthAfterIdle';       // Time in minutes that session is allowed to idle before forcing reAuth
    public const BLK_AFTER_LOGOUT   =   'blockAfterEnfocedLogout';      // Time to block user after he/she was forcefully logged out.

    // https://codeberg.org/QuinQuies/glpisaml/issues/37
    public const POSTFIELD   = 'samlIdpId';
    public const GETFIELD    = 'samlIdpId';
    public const SAMLBYPASS  = 'bypass';
    public const SLOLOGOUT   = 'sloLogout';
    public const LOCALLOGOUT = 'localLogout';

    /**
     * Holds the state object
     * @var ?LoginState
     */
    protected ?LoginState $state;

    /**
     * Holds the currently active state object for static error handlers to log details.
     * @var ?LoginState
     */
    public static ?LoginState $activeState = null;

    /**
     * Support exception throwing in tests instead of exiting.
     * @var bool
     */
    public static bool $throwOnError = false;

    /**
     * Holds the captured user piripheral name if any.
     * @var string subject
     */
    protected ?string $subject;

    /**
     * Overloads missing canCreate Setup right and returns canUpdate instead
     *
     * @return bool     Returns true if profile assigned Setup->Setup->Update right
     * @see             https://github.com/pluginsGLPI/example/issues/50
     */
    public static function canCreate(): bool
    {
        return (bool) static::canUpdate();
    }

    /**
     * Overloads missing canDelete Setup right and returns canUpdate instead
     *
     * @return bool     Returns true if profile assigned Setup->Setup->Update right
     * @see             https://github.com/pluginsGLPI/example/issues/50
     */
    public static function canDelete(): bool
    {
        return (bool) static::canUpdate();
    }

    /**
     * Overloads missing canPurge Setup right and returns canUpdate instead
     *
     * @return bool     Returns true if profile assigned Setup->Setup->Update right
     * @see             https://github.com/pluginsGLPI/example/issues/50
     */
    public static function canPurge(): bool
    {
        return (bool) static::canUpdate();
    }

    /**
     * returns class friendly TypeName.
     *
     * @param  int      $nb return plural or singular friendly name.
     * @return string   returns translated friendly name.
     */
    public static function getTypeName($nb = 0): string
    {
        return __('samlFlow', PLUGIN_NAME);
    }

    /**
     * Returns class icon to use in menus and tabs
     *
     * @return string   returns Font Awesome icon className.
     * @see             https://fontawesome.com/search
     */
    public static function getIcon(): string
    {
        return 'fa-fw fas fa-sign-in-alt';
    }

    // LOGIN FLOW AFTER PRESSING A IDP BUTTON.
    /**
     * Evaluates the session and determines if login/logout is required
     * Called by post_init hook via function in hooks.php. It watches POST
     * information passed from the loginForm.
     *
     * @return  null
     * @since                   1.0.0
     */
    public function doAuth()                         //NOSONAR - complexity by design
    {


        /**
         * Do not process login flow if the user is already logged in, unless they are logging out.
         */
        $requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
        if (!is_string($requestPath)) {
            $requestPath = '';
        }
        $isLogout = str_contains($requestPath, SamlSsoController::SLO_ROUTE) ||
                    isset($_GET[self::SLOLOGOUT]) ||
                    isset($_GET[self::LOCALLOGOUT]);

        /**
         * Do not process anything if we are handling an ACS call.
         * Generating a state in this phase will taint it because we
         * have a new sessionId that will not align with existing entries
         * and need to use the samlRequestId to populate the state object.
         *
         * @see https://github.com/DonutsNL/samlsso/issues/29
         */
        if (str_contains($requestPath, SamlSsoController::ACS_ROUTE)) {
            return;
        }

        // Make the GLPI configuration available.
        global $CFG_GLPI;

        // Get current state this can either be an initial state (new session) or
        // an existing one. The state properties tell which one we are dealing with.
        try {
            $this->state = new Loginstate();
            self::$activeState = $this->state;
        } catch (Throwable $e) {
            $this->printError(sprintf(__("Loading login state failed with: %s", PLUGIN_NAME), (string)$e));
        }

        LoginState::expireStaleGlpiSessions();

        if ($this->state->getPhase() === LoginState::PHASE_FORCE_LOG) {
            $this->state->setPhase(LoginState::PHASE_LOGOFF);
            Session::cleanOnLogout();
            if (\Toolbox::isAjax()) {
                http_response_code(401);
                exit;
            }
            Session::addMessageAfterRedirect(__('You have been forcefully logged out by an administrator.', PLUGIN_NAME), false, ERROR);
            header('Location: ' . $CFG_GLPI['url_base'] . '/index.php?noAuto=1');
            exit;
        }

        if ($this->state->getPhase() === LoginState::PHASE_TIMED_OUT) {
            $this->state->setPhase(LoginState::PHASE_LOGOFF);
            Session::cleanOnLogout();
            if (\Toolbox::isAjax()) {
                http_response_code(401);
                exit;
            }
            Session::addMessageAfterRedirect(__('Your session has timed out due to inactivity.', PLUGIN_NAME), false, ERROR);
            header('Location: ' . $CFG_GLPI['url_base'] . '/index.php?noAuto=1');
            exit;
        }

        /**
         * Skip authentication logic for AJAX requests to avoid session state
         * corruption during background operations.
         */
        if (\Toolbox::isAjax()) {
            return;
        }

        // If we hit an excluded file, we return and do nothing, not even log the
        // event. Possibly we want to enable the user to perform SIEM calls by
        // implementing this functionality prior to this validation.
        if (Exclude::isExcluded()) {
            return;
        }

        // If this is an initial state, write it to database
        if ($this->state->getStateId() == -1) {
            $this->state->writeState();
        }

        /**
         * Run invalidation logic for unauthenticated flows, throttled periodically (Issues #151, #166).
         */
        if ($isLogout || Session::getLoginUserID() === false) {
            LoginState::expireStaleAcsRequests();
            LoginState::expireStaleGlpiSessions();
        }

        if (!$isLogout && Session::getLoginUserID() !== false) {
            $this->state->updateLastActivity();
            return;
        }

        if (isset($_GET[self::LOCALLOGOUT])) {
            $this->state->setPhase(LoginState::PHASE_LOGOFF);
            return;
        }

        // Perform SLO logout with idp
        // Called by $this->performLogOff()
        if (isset($_GET[self::SLOLOGOUT])) {
            $idpId = $this->state->getIdpId();
            if ($idpId > 0) {
                $configEntity = new ConfigEntity($idpId);
                if ($configEntity->isValid() && $configEntity->isActive()) {
                    $samlConfig = $configEntity->getPhpSamlConfig();
                    if (!empty($samlConfig)) {
                        $this->state->setPhase(LoginState::PHASE_LOGOFF);
                        Session::cleanOnLogout();
                        $samlAuth = new samlAuth($samlConfig);
                        // Get the (signed) logout url.
                        $sloUrl = $samlAuth->logout();
                        header('location:' . $sloUrl);
                        exit;
                    }
                }
            }
            // Fallback: if SLO configuration is not valid/active, clear local session and redirect to home
            $this->state->setPhase(LoginState::PHASE_LOGOFF);
            Session::cleanOnLogout();
            header('Location: ' . $CFG_GLPI['url_base'] . '/');
            exit;
        }

        // Store any redirects passed to GLPI in the state,
        // so we can process them after the auth redirects.
        $this->state->setRedirect();

        // Is the LOGOUT button PRESSED?
        // https://codeberg.org/QuinQuies/glpisaml/issues/18
        $requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
        if (!is_string($requestPath)) {
            $requestPath = '';
        }

        if (str_contains($requestPath, SamlSsoController::SLO_ROUTE) && !isset($_GET[self::LOCALLOGOUT])) {

            $this->performLogOff();
            // If we reach this then GLPI should handle the logoff not us.
            return;
        }

        // Do nothing if glpi is trying to impersonate someone
        // Let GLPI handle auth in this scenario
        // https://codeberg.org/QuinQuies/glpisaml/issues/159
        if (
            isset($_POST['impersonate']) &&
            $_POST['impersonate'] == '1' &&
            !empty($_POST['id'])
        ) {

            $this->state->addLoginFlowTrace(['Impersonated someone' => true]);
            return;
        }

        // BYPASS SAML ENFORCE OPTION
        // https://codeberg.org/QuinQuies/glpisaml/issues/35
        $this->interceptBypass();

        // CAPTURE LOGIN FIELD
        // https://codeberg.org/QuinQuies/glpisaml/issues/3
        // https://github.com/DonutsNL/samlsso/issues/16
        if (($id = $this->resolveIdpFromLoginForm())) {
            $_POST[LoginFlow::POSTFIELD] = $id;
        }

        // MANUAL IDP ID VIA GETTER
        // Check if the user manually provided the correct idp to use
        // this to provision Idp Initiated SAML flows.
        if (
            isset($_GET[LoginFlow::GETFIELD])        &&                                                          // If correct SAML config ID was provided manually, use that
            is_numeric($_GET[LoginFlow::GETFIELD])
        ) {                                                          // Make sure its a numeric value and not a string

            $this->state->addLoginFlowTrace(['loginViaGetter' => 'getValue:' . $_GET[LoginFlow::GETFIELD]]);
            $_POST[LoginFlow::POSTFIELD] = $_GET[LoginFlow::GETFIELD];
        }

        // Check if we only have 1 configuration and its enforced
        // https://codeberg.org/QuinQuies/glpisaml/issues/61
        if (($this->state->getPhase() == LoginState::PHASE_INITIAL   ||      // Make sure we only do this if state is initial
                $this->state->getPhase() == LoginState::PHASE_LOGOFF)   &&      // Make sure we only do this if state is logoff
            Config::getIsOnlyOneConfig()                            &&      // Only perform this login type with only one samlConfig entry
            Config::getIsEnforced()                                 &&      // Only Enforce if we have enforced option configured.
            !isset($_GET['noAuto'])                                 &&      // Only perform this if GLPI 'noAuto' is absent.
            !isset($_GET[LoginFlow::SAMLBYPASS])
        ) {      // Only perform this if user is not trying to bypass samlAuth.

            $this->state->addLoginFlowTrace(['OnlyOneIdpEnforced' => 'idpId:' . Config::getIsOnlyOneConfig()]);
            $_POST[LoginFlow::POSTFIELD] = Config::getIsOnlyOneConfig();
        }

        // https://github.com/DonutsNL/samlsso/issues/12 add typecast.
        // Check if a SAML button was pressed and handle the corresponding logon request!
        if (
            isset($_POST[LoginFlow::POSTFIELD])                  &&      // Must be set
            is_numeric($_POST[LoginFlow::POSTFIELD])             &&      // Value must be numeric
            strlen((string) $_POST[LoginFlow::POSTFIELD]) < 3
        ) {      // Should not exceed 999

            $this->state->addLoginFlowTrace(['finalIdp' => 'idpId:' . $_POST[LoginFlow::POSTFIELD]]);
            // If we know the idp we register it in the login State
            // the input is validated as is_numeric. Floats will be truncated by
            // the cast to int (int).
            $this->state->setIdpId((int) filter_var($_POST[LoginFlow::POSTFIELD], FILTER_SANITIZE_NUMBER_INT));

            // Actually perform SSO
            $this->performSamlIdpRequest();
        }
        // Do nothing and return nothing.
        // Returning an value like false breaks glpi in all kinds of nasty ways.
    }

    /**
     * Intercept and handle bypass SAML authentication requests.
     *
     * @return bool True if bypass was triggered
     */
    private function interceptBypass(): bool
    {
        global $CFG_GLPI;

        $bypassRequested = (isset($_GET[LoginFlow::SAMLBYPASS]) && $_GET[LoginFlow::SAMLBYPASS] == 1);
        $noAutoRequested = isset($_GET['noAuto']);
        $noAutoUpperSet = isset($_GET['noAUTO']);

        if ($bypassRequested || $noAutoRequested) {
            $requiredToken = defined('PLUGIN_SAMLSSO_BYPASS_TOKEN')
                ? (string)PLUGIN_SAMLSSO_BYPASS_TOKEN
                : (string)getenv('SAMLSSO_BYPASS_TOKEN');
            $providedToken = $_GET['token'] ?? $_GET['bypass_token'] ?? null;

            if ($requiredToken === '' || $providedToken === null || !hash_equals($requiredToken, (string)$providedToken)) {
                return false;
            }

            $_SESSION['glpi_plugins']['samlsso']['bypass_token'] = (string)$providedToken;
            $_SESSION['glpi_plugins']['samlsso']['bypass'] = true;

            if (!$bypassRequested || !$noAutoUpperSet) {
                $this->state->addLoginFlowTrace(['bypassUsed' => true]);
                $url = $CFG_GLPI['url_base'] . '/?' . LoginFlow::SAMLBYPASS . '=1&noAUTO=1&token=' . urlencode((string)$providedToken);
                header('Location:' . $url);
                exit();
            }
            return true;
        }
        return false;
    }

    /**
     * Parse the login form parameters to see if IDP matching the domain is configured.
     *
     * @return int|null Resolved IDP configuration ID, or null
     */
    private function resolveIdpFromLoginForm(): ?int
    {
        foreach ($_POST as $key => $value) {
            if (str_contains((string)$key, 'login_name') && !empty($_POST[$key])) {
                $id = Config::getConfigIdByEmailDomain($_POST[$key]);
                if ($id) {
                    $this->state->addLoginFlowTrace(['loginViaUserfield' => 'user:' . $_POST[$key] . ',idpId:' . $id]);
                    $this->subject = $_POST[$key];
                    return (int)$id;
                }
            }
        }
        return null;
    }

    /**
     * Method uses phpSaml to perform a sign-in request with the
     * selected Idp that is stored in the state. The Idp will
     * perform the sign-in and if successful perform a user redirect
     * to /plugins/samlsso/front/acs.php
     *
     * @return  void
     * @since                           1.0.0
     */
    protected function performSamlIdpRequest(): void
    {
        global $CFG_GLPI;

        $samlConfig = [];
        $auth = null;
        $ssoBuiltUrl = '';

        // Fetch the correct configEntity GLPI
        if (($configEntity = new ConfigEntity($this->state->getIdpId()))) { // Get the configEntity object using our stored ID
            $samlConfig = $configEntity->getPhpSamlConfig();      // Get the correctly formatted SamlConfig array
        }

        // Validate if the IDP configuration is enabled
        // https://codeberg.org/QuinQuies/glpisaml/issues/4
        if ($configEntity->isActive()) {                            // Validate the IdP config is activated

            // Initialize the OneLogin phpSaml auth object
            // using the requested phpSaml configuration from
            // the samlsso config database. Catch all throwable
            // errors and exceptions.
            try {
                $auth = new samlAuth($samlConfig);
            } catch (Throwable $e) {
                $safeConfig = $samlConfig;
                if (isset($safeConfig['sp']['privateKey'])) {
                    $safeConfig['sp']['privateKey'] = '***REDACTED***';
                }
                $this->printError($e->getMessage(), 'Saml::Auth->init', var_export($safeConfig, true));
            }

            // Added version 1.2.0
            // Capture and register requestId in database
            // before performing the redirect so we don't need Cookies
            $forceAuthn = false;
            if ($configEntity !== null) {
                $forceAuthn = (bool) $configEntity->getField(ConfigEntity::FORCE_AUTHN);
            }

            $flowToken = bin2hex(random_bytes(16));
            if (method_exists($this->state, 'setFlowToken')) {
                $this->state->setFlowToken($flowToken);
            }
            $_SESSION['glpi_plugins']['samlsso']['flow_token'] = $flowToken;

            try {
                $ssoBuiltUrl = $auth->login(
                    $flowToken,
                    array(),
                    $forceAuthn,
                    false,
                    true,
                    true,
                    null
                );
            } catch (Throwable $e) {
                $this->printError($e->getMessage(), 'Saml::Auth->init', var_export($auth->getErrors(), true));
            }

            if ($auth !== null) {
                $this->state->setRequestId($auth->getLastRequestID());
            }

            $this->state->refreshLoginDateTime();
            if (!$this->state->setPhase(LoginState::PHASE_SAML_ACS)) {
                $this->printError(sprintf(__('Could not update the loginState and therefor stopped the loginFlow for: %s', PLUGIN_NAME), (string)($_POST[LoginFlow::POSTFIELD] ?? $this->state->getIdpId())));
            }

            // Perform redirect to Idp using HTTP-GET
            header('Pragma: no-cache');
            header('Cache-Control: no-cache, must-revalidate');
            header('Location: ' . $ssoBuiltUrl);
            exit();
        } // Do nothing, ignore the samlSSORequest.
    }


    /**
     * Called by the src/LoginFlow/Acs class if the received response was valid
     * to handle the samlLogin or invalidate the login if there are deeper issues
     * with the response, for instance important claims are missing.
     *
     * @param   Response    SamlResponse from Acs.
     * @param   LoginState  The correct state loaded with the samlRequestId passed by ACS
     * @return  void
     * @since               1.0.0
     */
    protected function performGlpiLogin(Response $response, LoginState $state): void
    {
        global $CFG_GLPI;
        $auth = null;

        // Push the state into this objects property just in case.
        $this->state = $state;

        // Validate samlResponse and extract provided attributes (saml claims).
        // This validation will print and exit(!) on errors because user information is mandatory
        // after this step.
        $userFields = User::getUserInputFieldsFromSamlClaim($response, $state->getIdpId());

        // Resolve the ConfigEntity to propagate down the authentication chain
        $configEntity = ($this instanceof \GlpiPlugin\Samlsso\LoginFlow\Acs) ? $this->configEntity : new ConfigEntity($state->getIdpId());

        // Try to populate GLPI Auth using the fetched samlResponse attributes;
        try {
            $auth = (new GlpiAuth())->loadUser($userFields, $configEntity, $state);
        } catch (Throwable $e) {
            $this->printError($e->getMessage(), 'doSamlLogin');
        }

        // update the state that samlAuth was succesfull.
        $this->state->setSamlAuthTrue();

        // Before we continue we need to make sure to have a valid GLPI session. This is important
        // because the initiall call was stateless. At this point we want to start authenticating
        // the saml user with GLPI (merge auth) and we need a valid glpi session for that, that will
        // survive the next redirect back to GLPI. For this we need to make the session statefull and
        // perform a browser redirect (meta refresh) to remove any taints in the browsers requestchain.
        ini_set('session.use_cookies', 1);  // Renable Cookies Disabled by PostBootListner/SessionStart.php:106
        Session::destroy();                 // Clean existing session
        Session::start();                   // Create a new statefull one.

        if ($auth !== null) {
            if (!empty($auth->getErrors())) {
                LoginFlow::PrintFatalLoginError(implode("<br />", $auth->getErrors()));
            }

            Session::init($auth);
        }

        // Update the samlState table with the new sessionId.
        // so we can keep tracking it after the next redirect.
        // https://github.com/DonutsNL/samlsso/issues/26
        $state->setSessionId();

        // Dont depend on GLPI core to perform the correct type of redirect.
        $this->performBrowserRedirect();
    }

    /**
     * Makes sure user is logged out of GLPI, and if requested also logged out from SAML.
     * @return void
     */
    protected function performLogOff(): void
    {
        global $CFG_GLPI;

        // Make sure we are looking at a logged in session
        // before showing this.
        if (!array_key_exists('glpiID', $_SESSION) || empty($_SESSION["glpiID"])) {
            // Ignore the call.
            return;
        }

        // Update flowtrace field.
        $this->state->addLoginFlowTrace(['logoutPressed' => true]);

        // Get IdpConfiguration if any and figure out if we
        // need to handle some sort of logout at the IDP or
        // just ignore the logout request and let GLPI handle it.
        $configEntity = new ConfigEntity($this->state->getIdpId());         // Get the correct IDP configuration using the state.

        // If the session is samlAuthed and the SLO url was configured
        // capture the logout and present an option to logout with the
        // IDP in addition to logging out of GLPI.
        if (
            $configEntity->getField(ConfigEntity::IDP_SLO_URL)  &&
            $this->state->isSamlAuthed()
        ) {

            $isEnforced = (bool) $configEntity->getField(ConfigEntity::ENFORCE_SSO);
            $idpName = htmlentities((string) $configEntity->getField(ConfigEntity::NAME));

            $returnLabel = $isEnforced ? __('Go back to GLPI', PLUGIN_NAME) : __('Continue with local logout', PLUGIN_NAME);
            $sloLabel    = __('Log out everywhere', PLUGIN_NAME);

            if ($isEnforced) {
                $infoText = sprintf(
                    __('You have been authenticated using the SAML2 identity provider: <b>%1$s</b>.<br><br>Because SAML authentication is enforced, logging out of GLPI locally will automatically log you back in immediately.<br><br>To sign out completely, please select <b>\'%2$s\'</b>. Note that this will also terminate your active sessions in all other applications connected to this Identity Provider.<br><br>If you want to leave GLPI, just close this browser tab.', PLUGIN_NAME),
                    $idpName,
                    $sloLabel
                );
            } else {
                $infoText = sprintf(
                    __('You have been authenticated using the SAML2 identity provider: <b>%1$s</b>.<br><br>You can log out permanently by also logging out with the IDP by pressing <b>\'%2$s\'</b> (which terminates active sessions in all other applications depending on it), or perform a local logout from GLPI only by pressing <b>\'%3$s\'</b>.', PLUGIN_NAME),
                    $idpName,
                    $sloLabel,
                    $returnLabel
                );
            }

            // Define static translatable elements
            $tplVars = [
                'header'        => __('🤔 How would you like to proceed?', PLUGIN_NAME),
                'idpName'       => $configEntity->getField(ConfigEntity::NAME),
                'infoText'      => $infoText,
                'returnLabel'   => $returnLabel,
                'returnPath'    => $isEnforced ? $CFG_GLPI["url_base"] . '/' : $CFG_GLPI["url_base"] . '/front/logout.php?' . self::LOCALLOGOUT . '=1&noAUTO=1',
                'closeLabel'    => __('Close tab', PLUGIN_NAME),
                'sloLabel'      => $sloLabel,
                'sloPath'       =>  $CFG_GLPI["url_base"] . '/front/logout.php?' . self::SLOLOGOUT . '=1',
                'isEnforced'    => $isEnforced,
            ];

            // print GLPI headers
            Html::nullHeader("SamlSSO Logout catcher", '/');
            // Render twig template
            // https://codeberg.org/QuinQuies/glpisaml/issues/12
            echo TemplateRenderer::getInstance()->render('@samlsso/logout.html.twig',  $tplVars);
            // print nullFooter
            Html::nullFooter();

            // Note: GLPI session is NOT cleared here; it will be cleared once the user selects localLogout or sloLogout.
            exit;
        } else {
            Session::cleanOnLogout();
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_regenerate_id(true);
            }
        }
    }


    /**
     * Responsible to generate the login buttons to show in conjunction
     * with the glpi login field (not enforced). Only shows if there are
     * buttons to show. Else it will skip.
     *
     * @see https://github.com/DonutsNL/glpisaml/issues/7
     * @return  string  html form for the login screen
     * @since           1.0.0
     */
    public function showLoginScreen(): void
    {
        // Validate if we need to hide the login fields?
        if (Config::getHideLoginFields()) {
            echo '<style>
                   .card-body div.mb-4:has(#login_password) {
                        display: none;
                    }
                    .card-body div.mb-3:has([id^="dropdown_auth"]){
                        display:none;
                    }
                    .card-body div.mb-2:has(#login_remember){
                        display:none;
                    }
                  </style>';
        }

        $tplVars = Config::getLoginButtons(12);         // Fetch the global DB object;
        if (!empty($tplVars)) {                           // Only show the interface if we have buttons to show.
            // Define static translatable elements
            $tplVars['action']     = samlsso_plugin_web_dir();
            $tplVars['header']     = !empty($tplVars['header']) ? $tplVars['header'] : __('Login with external provider', PLUGIN_NAME);
            $tplVars['showbuttons']    = true;
            $tplVars['postfield']  = LoginFlow::POSTFIELD;
            $tplVars['enforced']   = Config::getIsEnforced();
            // https://codeberg.org/QuinQuies/glpisaml/issues/12
            TemplateRenderer::getInstance()->display('@samlsso/loginScreen.html.twig',  $tplVars);
        } else {
            $tplVars['enforced'] = Config::getIsEnforced() && !isset($_GET['bypass']); // Validate there is 'an' enforced saml Config and we don't want to bypass
            if ($tplVars['enforced']) { // Validate we don't want to bypass our enforcement
                // Call the renderer to render our CSS injection.
                TemplateRenderer::getInstance()->display('@samlsso/loginScreen.html.twig',  $tplVars);
            }
        }
    }

    // ERROR HANDLING
    /**
     * Prints and logs a Fatal login error with human readable message and doesnt offer
     * any 'back' options. used mainly in the ACS flow where the only option is
     * to correct configuration issues.
     *
     * @see https://github.com/DonutsNL/glpisaml/issues/7
     * @param string   error message to show
     * @since 1.0.0
     */
    public static function PrintFatalLoginError($errorMsg): never
    {
        global $CFG_GLPI;

        $ip = getenv("HTTP_X_FORWARDED_FOR") ?: getenv("REMOTE_ADDR");

        /* Log in file */
        Toolbox::logInFile(PLUGIN_NAME . "-errors", 'FATAL SAML LOGIN ERROR:' . $errorMsg . "\n", true);

        if (self::$throwOnError) {
            throw new \Exception((string)$errorMsg);
        }

        $debug = false;
        try {
            $state = self::$activeState;
            if ($state === null || $state->getStateId() <= 0) {
                $state = new Loginstate();
            }
            if ($state->getStateId() > 0) {
                if ($state->getPhase() !== LoginState::PHASE_GLPI_AUTH) {
                    $state->addLoginFlowTrace(['Fatal Error' => (string)$errorMsg]);
                    $state->setPhase(LoginState::PHASE_ERROR);
                }
                if ($state->getIdpId() > 0) {
                    $configEntity = new ConfigEntity($state->getIdpId());
                    $debug = (bool)$configEntity->getField(ConfigEntity::DEBUG);
                }
            }
        } catch (\Throwable $t) {
            /* ignore */
        }

        $displayMsg = $debug ? (string)$errorMsg : __('Something went wrong during authentication assertion and prevents you from logging in. Please contact your GLPI administrator for more information and support.', PLUGIN_NAME);

        /* Define static translatable elements */
        $tplVars['header']      = __('⚠️ Sorry we are unable to log you in', PLUGIN_NAME);
        /* https://github.com/DonutsNL/samlsso/issues/21 */
        /* Typecast might break if the passed object doesnt have a __toString() magic method. */
        $tplVars['error']       = htmlentities($displayMsg);
        $tplVars['returnPath']  = $CFG_GLPI["url_base"] . '/';
        $tplVars['returnLabel'] = __('Return to GLPI', PLUGIN_NAME);

        // print header
        http_response_code(403); // AccessDeniedHttpException
        Html::nullHeader("Login",  $CFG_GLPI["url_base"] . '/');
        // Render twig template
        // https://codeberg.org/QuinQuies/glpisaml/issues/12
        echo TemplateRenderer::getInstance()->render('@samlsso/loginError.html.twig',  $tplVars);
        // print footer
        Html::nullFooter();

        // Make sure php execution is stopped.
        exit;
    }


    /**
     * Prints and logs error message with 'back' button
     *
     * @see https://github.com/DonutsNL/glpisaml/issues/7
     * @param string errorMsg   string with raw error message to be printed
     * @param string action     optionally add 'action' that was performed to error message
     * @param string extended   optionally add 'extended' information about the error in the log file.
     * @return void             no return, PHP execution is terminated by this method.
     * @since 1.0.0
     */
    public static function printError(string $errorMsg, string $action = '', string $extended = ''): never
    {
        // Pull GLPI config into scope.
        global $CFG_GLPI;

        /* Log in file */
        Toolbox::logInFile(PLUGIN_NAME . "-errors", $errorMsg . "\n", true);
        if ($extended) {
            Toolbox::logInFile(PLUGIN_NAME . "-errors", $extended . "\n", true);
        }

        if (self::$throwOnError) {
            throw new \Exception($errorMsg);
        }

        $debug = false;
        try {
            $state = self::$activeState;
            if ($state === null || $state->getStateId() <= 0) {
                $state = new Loginstate();
            }
            if ($state->getStateId() > 0) {
                if ($state->getPhase() !== LoginState::PHASE_GLPI_AUTH) {
                    $state->addLoginFlowTrace(['Error' => $errorMsg . ($extended ? ": " . $extended : "")]);
                    $state->setPhase(LoginState::PHASE_ERROR);
                }
                if ($state->getIdpId() > 0) {
                    $configEntity = new ConfigEntity($state->getIdpId());
                    $debug = (bool)$configEntity->getField(ConfigEntity::DEBUG);
                }
            }
        } catch (\Throwable $t) {
            /* ignore */
        }

        $displayMsg = $debug ? $errorMsg : __('Something went wrong during authentication assertion and prevents you from logging in. Please contact your GLPI administrator for more information and support.', PLUGIN_NAME);

        /* Define static translatable elements */
        $tplVars['header']      = __('⚠️ An error occurred', PLUGIN_NAME);
        $tplVars['leading']     = __("We are sorry, something went wrong while processing your request!", PLUGIN_NAME);
        $tplVars['error']       = $displayMsg;
        $tplVars['returnPath']  = $CFG_GLPI["url_base"] . '/';
        $tplVars['returnLabel'] = __('Return to GLPI', PLUGIN_NAME);
        // print header
        http_response_code(400); // BadRequestHttpException
        Html::nullHeader("Login",  $CFG_GLPI["url_base"] . '/');
        // Render twig template
        echo TemplateRenderer::getInstance()->render('@samlsso/errorScreen.html.twig',  $tplVars);
        // print footer
        Html::nullFooter();

        // Make sure php execution is stopped.
        exit;
    }

    /**
     * Perform browser redirect to make sure we send a HTTP200 OK. The HTTP200 OK is
     * needed to ensure the browser resets the request chain originating from the IDP.
     * Not resetting the chain will invalidate the GLPI cookies.
     *
     * @see https://github.com/DonutsNL/glpisaml/issues/7
     * @return void             no return, PHP execution is terminated by this method.
     * @since 1.0.0
     */
    public static function performBrowserRedirect(): never
    {
        // reference global config;
        global $CFG_GLPI;
        $state = null;
        try {
            $state = new Loginstate();
        } catch (Throwable $e) {
            LoginFlow::printError(sprintf(__("Loading login state failed with: %s", PLUGIN_NAME), (string)$e));
        }

        $safeRedirect = $state !== null ? $state->getSafeRedirect() : '';
        if (!empty($safeRedirect)) {
            if (str_starts_with($safeRedirect, '/')) {
                $url = rtrim($CFG_GLPI['url_base'], '/') . $safeRedirect;
            } else {
                $url = rtrim($CFG_GLPI['url_base'], '/') . '/?redirect=' . rawurlencode($safeRedirect);
            }
        } else {
            $url = $CFG_GLPI['url_base'];
        }

        printf(
            '<!DOCTYPE html>
                <html>
                    <head>
                        <meta charset="UTF-8" />
                        <meta http-equiv="refresh" content="0;url=\'%1$s\'" />

                        <title>%2$s</title>
                    </head>
                    <body>&nbsp;</body>
                </html>',
            \htmlescape($url),
            'Auth succesfull'
        );
        exit;
    }

    /**
     * Install the LoginFlow DB table
     * @param   Migration $obj
     * @return  void
     * @since   1.0.0
     */

    /*  //NOSONAR - This is in preparation of version 1.2.0 but should not YET be processed by
        //          the hook.php install
    public static function install(Migration $migration) : void
    {
        global $DB;
        $default_charset = DBConnection::getDefaultCharset();
        $default_collation = DBConnection::getDefaultCollation();
        $default_key_sign = DBConnection::getDefaultPrimaryKeySignOption();

        $table = LoginState::getTable();

        // Create the base table if it does not yet exist;
        // Do not update this table for later versions, use the migration class;
        if (!$DB->tableExists($table)) {
            // Create table
            $query = <<<SQL
            CREATE TABLE IF NOT EXISTS `$table` (
                `id`                        int {$default_key_sign} NOT NULL AUTO_INCREMENT,
                `debug`                     tinyint NOT NULL DEFAULT 0,
                `enforced`                  tinyint NOT NULL DEFAULT 0,
                `forcedIdp`                 int DEFAULT -1,
                `enableGetterLogin`         tinyint NOT NULL DEFAULT 0,
                `hideGlpiLogin`             tinyint NOT NULL DEFAULT 0,
                `hideSamlButtons`           tinyint NOT NULL DEFAULT 0,
                `hideUsername`              tinyint NOT NULL DEFAULT 0,
                `useCustomLoginTemplate`    varchar(255) NULL,
                `byPassString`              varchar(255) DEFAULT '1',
                `byPassVar`                 varchar(255) DEFAULT 'bypass',
                `enableIdpLogout`           tinyint NOT NULL DEFAULT 0,
                `enforceReAuthAfterIdle`    int NOT NULL DEFAULT -1,                        // Time in minutes that session is allowed to idle before forcing reAuth
                `blockAfterEnfocedLogout`   int NOT NULL DEFAULT -1,                        // Time to block user after he/she was forcefully logged out.
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET={$default_charset} COLLATE={$default_collation} ROW_FORMAT=COMPRESSED;
            SQL;
            $DB->doQuery($query) or die($DB->error());
            Session::addMessageAfterRedirect("🆗 Installed: $table.");
        }
    }
    */

    /**
     * Uninstall the LoginState DB table
     * @param   Migration $obj
     * @return  void
     * @since   1.0.0
     */

    /*  //NOSONAR - This is in preparation of version 1.2.0 but should not YET be processed by
        //          the hook.php install
    public static function uninstall(Migration $migration) : void
    {
        $table = LoginState::getTable();
        $migration->dropTable($table);
        Session::addMessageAfterRedirect("🆗 Removed: $table.");
    }
    */
}
