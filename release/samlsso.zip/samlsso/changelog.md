**V1.4.0**
- Aligned `README.md`, `docs/CONTRIBUTING.md`, `samlsso.xml`, `ADR 0001`, and `ADR 0008` with the `1.4.0` codebase for https://github.com/DonutsNL/samlsso/issues/201 (updating GLPI 11/12 compatibility, test suite badge count, SCIM 2.0 Beta feature/locale listings, SLO no-redirect invariant and call flow, and removing stale `PluginException`/`PluginContext` and contradictory comment guidance).
- Resolved CodeFactor quality, complexity, duplication, and security findings for https://github.com/DonutsNL/samlsso/issues/200 without behavioral changes: aligned `ADR 0008` and agent coding guidelines to avoid assignments inside conditionals; collapsed redundant shorthands and duplicate selectors in `public/css/samlSSO.css`; removed assignment-in-condition and redundant string concatenation across `ConfigItem`, `ConfigForm`, `LoginFlow`, and `GlpiComplianceTest`; extracted shared `tools/translation/po_utils.py` and switched `generate_translations.py` to `http.client.HTTPSConnection`; deduplicated `LoginState` row hydration; and decomposed high-complexity methods across `LoginState`, `LoginFlow`, `Acs`, `User`, `ConfigEntity`, `ClaimMapEntity`, `ConfigItem`, `ConfigForm`, and the test suite.
- Fixed remaining schema upgrade bugs for https://github.com/DonutsNL/samlsso/issues/173 across `Config::install()`, `ClaimMap::install()`, and `LoginState::install()` by replacing invalid `Migration::fieldFormat()` types (`tinyint`, `int`, `VARCHAR(...)`) and ignored `'default'` / accidental `'update' => true` options with valid GLPI `'bool'` / `'integer'` / `'string'` / `'text'` definitions using `'value'`, backfilling `NULL` values and normalizing existing legacy columns (`sync_on_login`, `security_*`, `force_authn`, `request_timeout`, `inactivity_timeout`) via `$migration->changeField()`, and enforcing strict migration checks in `DatabaseUpdateTest`.
- Verified strict duplicate-row check (`$sessionIterator->numrows() !== 1`) in `LoginState::getState()` and added automated regression test coverage in `LoginStateTest` for https://github.com/DonutsNL/samlsso/issues/190.
- Removed the redundant stateless `RelayState` `$flowToken` (`setFlowToken()` / `getFlowToken()` / `FlowTokenMismatch`) check in `LoginFlow`, `LoginState`, and `Acs` so IdPs and Entra ID configurations using custom `RelayState` values no longer fail solicited ACS logins (https://github.com/DonutsNL/samlsso/issues/188), standardized outbound SLO/SSO `RelayState` on static `$CFG_GLPI['url_base'] ?? '/'` with empty parameter arrays and strictly server-side `LoginState::REDIRECT` (`ADR 0001`, enforced via `AdrComplianceTest`), and cleaned up dead/redundant additions (`LoginState::SAML_REQUEST` / `requestParams` column drop + `sessionId` log redaction, duplicate `assertSaml()` IdP checks, write-only `bypass_token` session key / redirect token leak in `LoginFlow::interceptBypass()`, and duplicate bypass logic in `Config::getHideLoginFields()`).
- Refined external user-source binding and LDAP migration tooling for https://github.com/DonutsNL/samlsso/issues/189 by namespacing SAML/SCIM `glpi_users.auths_id` values via `User::AUTHS_ID_OFFSET = 1000000` (`1,000,000 + $idpId`) so active `glpi_authldaps` servers never collide with SAML IdPs while preserving `/acs/{id}` and `/scim/v2/{id}` URLs, tightening `User::getOrCreateUser()` (`$idpId > 0`, rejecting `authtype = 0`, and stamping unbound `(Auth::EXTERNAL, 0)` accounts on one-time adoption across SAML and SCIM), auto-upgrading legacy unnamespaced external rows in `Config::install()`, and exposing `php bin/console plugins:samlsso:migrate_ldap_users` (`src/Console/MigrateLdapUsersCommand.php`) inside packaged release builds (`ADR 0004`, `ADR 0007`).
- Added Content Security Policy (CSP) readiness for https://github.com/DonutsNL/samlsso/issues/193 by replacing all inline `on*` event attributes across `logging.html.twig`, `provider.html.twig`, `claim_mapping.html.twig`, and `configForm.html.twig` with `data-*` attributes and delegated event listeners, extracting `ConfigForm::renderBackupRestoreCard()` into `templates/configBackupRestore.html.twig` with a Bootstrap confirmation modal, declaring `'csp_compliant' => true` in `plugin_version_samlsso()`, and adding automated CSP regression checks in `tests/AdrComplianceTest.php` (`ADR 0006`).
- Added per-IdP stateless HTTPS-only SCIM 2.0 user and group provisioning (Beta) for https://github.com/DonutsNL/samlsso/issues/199 (`/front/scim/v2/{idpId}`, `ScimAuthenticator` with SHA-256 `db` / `env` / `define` `hash_equals()` Bearer tokens, CIDR allowlist, and rate limiting, bounded local `ScimFilterParser` and `ScimPatchProcessor`, decoupled `ScimAttributeMapper` sharing `RuleSamlCollection` criteria, `(Auth::EXTERNAL, $idpId)` + `ScimLink` isolation, 3-mode `scim_group_policy` with `is_dynamic = 1` memberships and non-destructive group unlink, and immediate `PHASE_FORCE_LOG` + GLPI 11/12 token revocation), dropped deprecated `serverParams`, `loggedOff`, and `enforceLogoff` columns from `glpi_plugin_samlsso_states`, and standardized user, config, claim-map, rule-criteria, and group-membership property keys across `src/` (`LoginFlow\User`, `Scim\*`, `RuleSaml`, `LoginState`, `Config`, `ConfigItem`, `ConfigForm`, `ClaimMap`, `ClaimMapItem`, `ClaimMapEntity`, `ObservedClaim`, and `LdapUserMigrator`) on class constants (`User::*`, `ConfigEntity::*`, `ClaimMap::*`, `ClaimMapItem::*`, `ObservedClaim::*`, `LoginState::*`).

**V1.3.2**
- Fixed issue https://github.com/DonutsNL/samlsso/issues/189: Replaced single-row `getFromDBByCrit()` / `getFromDBbyEmail()` lookups in `User::getOrCreateUser()` with parameterized multi-candidate resolution (`User::findCandidateUsers()`) so multi-IdP/multi-source `name` or `email` rows never throw `TooManyResultsException` while failing closed on `Auth::DB_GLPI`, `'glpi'`, or foreign-source collisions, and added the non-destructive, reversible `tools/migrate_ldap_users.php` CLI utility (`0600` `GLPIKey` HMAC-signed user-ID register, `--list-registers`, `--revert`, and active `glpi_authldaps` sync guard).
- Fixed issue https://github.com/DonutsNL/samlsso/issues/198: Aligned `session.cookie_samesite` validation in `plugin_samlsso_check_prerequisites()` (`setup.php`) with GLPI Core's `SessionsSecurityConfiguration` and `samlSSO`'s stateless ACS architecture so `Strict` and `Lax` both pass without false-positive warnings while `None` is flagged.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/197: Added `country`, `city`, and `street` to `ClaimMapItem::ALLOWED_RULE_FIELDS`, filtered `ClaimMapEntity::getUnusedRuleFields()` to active `RuleSaml` rules with canonical criterion alias mapping (`samlClaimedGroups`, `samlClaimedJobTitle`, `_useremails`, `name`), prevented duplicate built-in criteria and multi-value group scalar overwrites in `RuleSaml::getCriterias()` and `ClaimMapEntity::resolveRuleFields()`, tracked `registration_number` changes during `sync_on_login`, and stripped synthetic rule keys before `User::add()` / `User::update()`.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/196: Enforced `is_active = 1` in `Config::getIsEnforced()`, flushed pending `addField`/`addKey` migrations via `migrationOneTable()` in `ClaimMap::install()` and `Exclude::install()` while replacing legacy `or die()` calls with exceptions, aligned `CronTask::cronCleanSessionSAML()` with PHP runtime clock authority (`ADR 0002`), gated `HTTP_X_FORWARDED_FOR` behind `proxied` with IP validation in `LoginState`, completed `ConfigDefaultTpl` 1:1 field parity (`ADR 0005`), restored GLPI firewall checks and output buffering on `SamlSsoController` admin routes, prefixed `$CFG_GLPI['root_doc']` in `RuleSamlCollection::getRulesTestURL()`, hardened `GeoIPUpdater` with HTTPS-only cURL and atomic `rename()` writes, and standardized `hook.php` / `User.php` / `Acs.php` i18n strings.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/195: Fixed destructive backup restore failures (`getErrorMessages()` and pre-validation before table purge, plus full `$exportFields` parity), enforced verified session bypass tokens across `OnlyOneIdpEnforced` and `showLoginScreen()`, fixed `loginScreen.html.twig` (`strict_variables`, `enforced` CSS, and DOM structure), repaired `ConfigEntity::getAuthn()` for `RequestedAuthnContext`, passed authenticated `NameID` with `$stay = true` in SLO `logout()`, and resolved `strict_types` `TypeError`s, IdP ID `1..999` bounds, invalid `RedirectResponse` URLs, `?template=` handling, cookie prerequisite inversion, and double HTML-escaping.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/194: Removed unfinished `LoginFlowEntity`, `LoginFlowForm`, and `LoginFlowItem` scaffolding, removed stale `FLOWFORM_*` and `/front/slo/` route registrations, decoupled `LoginFlow` from `CommonDBTM` (`LoginFlowCompat`), pruned unused PHP state/config constants (`ENFORCE_LOGOFF`, `SAML_RESPONSE`, `RICHVALUE`, `PLUGIN_SAMLSSO_WEBDIR`), relocated `update_geoip.php` to `tools/`, and excluded `docs/` and `templates/images/` from `tools/mkzip.sh` release archives.
- Restructured all Architecture Decision Records (`docs/ADR/`) into 8 principle-driven Domain ADRs (`0001`–`0008`) and an ADR Governance & Authoring Guide (`0000`), added Two-Gate ADR Validation instructions (`CONTRIBUTING.md`, `SKILL.md`), and added `tests/AdrComplianceTest.php` to verify ADR structure and codebase invariants automatically.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/192: Delegated authenticated session inactivity management to GLPI core (`session.gc_maxlifetime`) while exposing the active GLPI session timeout as a read-only informational field in the Security configuration tab, initialized and refreshed `LoginState::LOGIN_DATETIME` (`loginTime`) from PHP's clock when SAML `AuthnRequest` messages are dispatched, and updated ACS request-timeout rejection (`PHASE_TIMED_OUT`) to queue a clear error message and redirect the user to `/index.php?noAuto=1` (ADR 0002).
- Fixed issue https://github.com/DonutsNL/samlsso/issues/147 and https://github.com/DonutsNL/samlsso/issues/180: Hardened `LoginFlow`, `LoginState`, and `Acs` against stateless replay session downgrade, empty `session_id()` collisions, unsigned response assertion-wrapping (`SubjectConfirmationData/@InResponseTo` and assertion ID uniqueness), and concurrent `setSamlResponseId()` races, and standardized ACS/SLO route matching on `SamlSsoController::ACS_ROUTE` and `SamlSsoController::SLO_ROUTE` across `setup.php`, `LoginFlow.php`, `Exclude.php`, and `LoginState.php` (ADR 0036).
- Fixed issue https://github.com/DonutsNL/samlsso/issues/147 and https://github.com/DonutsNL/samlsso/issues/180: Enforced state-machine re-authentication on unsolicited SAML responses (empty or unregistered `InResponseTo`) in `Acs::fetchRequestState()`, `Acs::assertSaml()`, and `LoginState::getState()` by persisting a new initial session state and redirecting the browser back to the IdP via `performSamlIdpRequest()` instead of authenticating unsolicited assertions directly, and bound `RelayState` exclusively to the per-flow CSRF token (ADR 0036).
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Completed RC4 security review remediation by enabling Bootstrap popover sanitization with a table-safe `allowList`, escaping login trace HTML directly on `$formattedParts[]` and `$trace .=` in `LoginState::getLoggingEntries()`, enforcing fail-closed IdP existence/active/deleted/route-ID checks and per-flow CSRF token verification in `Acs::init()`, gating fallback email account linking behind `sync_on_login` and `authtype`/`auths_id` binding in `User::getOrCreateUser()`, blanking `sp_private_key` in the configuration form while encrypting existing database keys during `Config::install()` and `restoreConfigEntry()`, requiring `SAMLSSO_BYPASS_TOKEN` to fail closed on `?bypass=1`, and shipping empty certificate/key defaults with `strict => true` and `security_wantassertionssigned => true` in `ConfigDefaultTpl`.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/187: Rendered diagnostic tables (`validateProxyEnvironment()` and `validateTimezoneEnvironment()`) inside label hover popovers as formatted HTML (`data-bs-html="true"`) with `sanitize: true` and a table-aware `allowList` in `SamlSsoPopoverManager.init()`, and hid raw inline diagnostic table containers from the configuration form to keep the interface clean and functional.
- Added ADR 0035 documenting HTML diagnostic table popover rendering and form cleanliness for issue https://github.com/DonutsNL/samlsso/issues/187.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/186: Preserved rich diagnostic HTML tables (such as proxy environment headers and timezone synchronizations) in configuration forms by adding explicit table guards in `processNotificationHelper()` to prevent tables from being flattened into plain text and hidden inside hover popovers, and ensured full-width responsive table layouts with flex-wrap in CSS.
- Added ADR 0034 documenting diagnostic table preservation and popover summary extraction for issue https://github.com/DonutsNL/samlsso/issues/186.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/185: Reallocated configuration form fields in `getTabWarnings()` so `request_timeout` and `inactivity_timeout` are evaluated under the Security tab where they are rendered, added missing `conf_icon_url`, `login_header_text`, and `force_authn` field mappings, prevented green timezone alignment success notices from triggering false-positive tab warning badges, and corrected duplicate `general-tab` ID on the Transit tab navigation anchor.
- Added ADR 0033 documenting configuration form tab warning alignment with template field placements for issue https://github.com/DonutsNL/samlsso/issues/185.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/184: Added interactive modal dialog for SP certificate and key generation allowing administrators to configure Common Name (CN), validity period, cryptotype (RSA / ECDSA), key lengths/curves, and signature digests, while strictly enforcing community security floors (minimum 2048 bits for RSA).
- Added ADR 0032 documenting the configurable modal dialog for SP certificate and key generation for issue https://github.com/DonutsNL/samlsso/issues/184.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/183: Added dynamic self-signed SP certificate and private key generation directly within the configuration UI when the default demo certificate (`withlove.from.donuts.nl`) is detected and OpenSSL is available.
- Added ADR 0031 documenting dynamic in-place SP certificate and private key generation for issue https://github.com/DonutsNL/samlsso/issues/183.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/182: Added dynamic input switching for alternative SP private key sources (file, env, define) with dedicated single-line text inputs and automatic raw PEM textarea disabling, and ensured pending table migrations execute on existing database upgrades via Config::install().
- Added ADR 0030 documenting dynamic SP private key source input switching and table migration execution for issue https://github.com/DonutsNL/samlsso/issues/182.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/181: Exposed GLPI core session lifetime (`session.gc_maxlifetime`) directly in the Security configuration tab with an explanation of its origin (ADR 0029).
- Fixed issue https://github.com/DonutsNL/samlsso/issues/178: Corrected the "INACTIVITY TIMEOUT (MINUTES)" translation in de_DE, el_GR, es_AR, es_ES, fi_FI, fr_FR, hi_IN, it_IT, nl_NL, pt_BR and sv_SE to resolve duplicate timeout label display, and recompiled the affected .mo files.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/177: Redirects to static assets (js, css, images, fonts) are no longer stored or used as post login target, preventing unauthenticated asset requests from overwriting deep links or sending users to raw assets after SSO login.
- Added ADR 0028 documenting the static asset redirect handling for issue https://github.com/DonutsNL/samlsso/issues/177.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Enforced administrative rights check (`Session::checkRight('config', UPDATE)`) and full ConfigEntity validation on backup and restore endpoints in ConfigForm.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Enforced strict SAML assertion validation in Acs, requiring wantAssertionsSigned or wantMessagesSigned, validating IdP configuration status, and rejecting cross-IdP assertion substitution.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Sanitized login flow trace logs and proxy headers with htmlspecialchars to prevent stored XSS in administrative session logs.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Protected local GLPI accounts (authtype DB_GLPI and default 'glpi' super-admin) against SAML JIT account takeover or linking, and stripped protected fields from synchronization updates.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Realigned SAML JIT rule authorization right from rule_import to rule_ldap.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Encrypted SP private keys using GLPIKey before database storage, masked private keys in UI, excluded keys from search options, and stripped keys from backup/export JSON payloads.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Removed raw OneLogin Response and $_SERVER dumps from logs to prevent secret and session token leakage.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Hardened SSO bypass with optional secret token validation and audit logging.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Enforced POST method and CSRF protection on forcelogoff, and enforced HTTP-POST binding on the ACS endpoint.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Evaluated forced logoff and inactivity timeouts before AJAX and exclusion checks (terminating AJAX with HTTP 401), and converted stale session cleanups to batch SQL queries.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Purged SAML JIT rules from glpi_rules, glpi_rulecriterias, and glpi_ruleactions upon plugin uninstallation.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Hardened code against XXE by removing LIBXML_NOENT and DTD loading flags from XML anonymization, and prevented PHP object injection by adding allowed_classes => false to unserialize calls.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/180: Replaced external third-party flagcdn.com image requests with offline Unicode flag emoji in session logging.
- Added ADR 0027 documenting the comprehensive security audit remediation for issue https://github.com/DonutsNL/samlsso/issues/180.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/173 and https://github.com/DonutsNL/samlsso/issues/171: Resolved SQL syntax error 1064 during table upgrade and plugin activation by converting column definitions in `Migration::addField()` from unsupported 'varchar' to 'string', removing conflicting 'update' => true on boolean/string fields to prevent accidental activation of 'force_authn', and normalizing any null values.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/171: Resolved false-positive schema validation failure and deactivation in SanityChecker on fresh installation by aligning column names with class constants (`ObservedClaim::SAML_CLAIM` and `Exclude::EXCLUDEPATH`) and making plugin path detection dynamic.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/159: Added configurable login screen header text (`login_header_text`) and custom button icon image URL (`conf_icon_url`) to IdP configuration, allowing administrators to customize the login screen header and display custom image/logo icons on login buttons without CSS overrides.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/153: Allowed additive multi-profile assignments across multiple JIT rules by removing the destructive loop in `User::assignProfileRights()` that deleted existing profile authorizations.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/156: Supported `_entities_id_default` and `_profiles_id_default` in `User::assignProfileRights()`, defaulted profile recursive assignment to `0` unless explicitly enabled, and replaced initial dynamic Root (0) authorization for the assigned profile to prevent users from being retained in Root entity.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/148: Ensured JIT rule outputs with `_profiles_id_default` and `_entities_id_default` are handled across both `User::assignProfileRights()` and `User::updateUserDefaults()`, and prevented false negative warning logs when database fields already match current settings.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/147: Handled IdP-initiated (unsolicited) SAML responses by creating a new `LoginState` record and redirecting the browser back to the IdP via `performSamlIdpRequest()` to re-evaluate authentication through the state machine.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/130: Added configurable "Force re-authentication" (`force_authn`) option to IdP configuration, setting `ForceAuthn="true"` on outgoing SAML AuthnRequests to ensure IdPs execute fresh authentication and authorization checks on every login.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/142: Added support for loading the SP private key from PHP defined constants (`define`) via `ConfigEntity::resolvePrivateKey()` and configuration dropdown options, allowing keys to be defined in `local_define.php` outside the database.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/137: Hardened codebase against PHP 8.0+ type regressions by guarding `$_SERVER['HTTP_USER_AGENT']` nullability in `Exclude::isExcluded()`, casting `requested_authn_context` before string operations in `ConfigEntity::getRequestedAuthnContextArray()`, and casting `$_POST` array keys to string in `LoginFlow::resolveIdpFromLoginForm()`.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/158: Preserved deep links across SAML authentication by capturing initial `REQUEST_URI` in `LoginState::setRedirect()` and restoring target redirects in `LoginFlow::performBrowserRedirect()`.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/166: Optimized ticket action performance by fast-pathing authenticated user requests in `LoginFlow::doAuth()`, bypassing global session cleanups during active user operations, and throttling `updateLastActivity()` database writes to 60-second intervals.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/151: Optimized stale ACS and inactivity session cleanups to execute targeted SQL queries filtered by cutoff timestamp instead of iterating all active sessions, and throttled execution to 5-minute intervals for unauthenticated requests.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/165: Expanded `glpi_plugin_samlsso_loginstates.redirect` column from `VARCHAR(255)` to `TEXT` to accommodate long search URLs with multiple filter criteria and eliminate HTTP 500 MySQL 1406 "Data too long" errors.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/160: Converted `glpi_plugin_samlsso_loginstates.phase` column from `TEXT` to `tinyint unsigned NOT NULL DEFAULT 1` and added index on `phase` to eliminate full table scans during request authentication.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/146: Filtered out empty/false SAML claims in `User::syncUserFieldsOnLogin()` before calling user update, preventing unasserted claims from wiping existing GLPI user attributes.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/162: Refreshed `LoginState::LOGIN_DATETIME` upon initiating new SAML authentication requests and transitioning to `PHASE_SAML_ACS`, preventing false "SAML request timed out" errors when re-authenticating from existing sessions.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/164: Registered '#^/front/logout#' as a stateless path in `setup.php` to prevent GLPI CSRF 403 Forbidden errors when IdPs post asynchronous SAML LogoutResponse messages.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/170: Adopted codebase for GLPI 12 compatibility, including PHP 8 property-type invariance, removed API migrations, strict form rendering, and test refactoring.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/134 by adding "registration_number" to user claim mapping by @froberts0n (PR https://github.com/DonutsNL/samlsso/pull/157).
- Fixed issue https://github.com/DonutsNL/samlsso/issues/167 / PR https://github.com/DonutsNL/samlsso/pull/169 by @beeone42: implemented dual GLPI 11 and GLPI 12 inheritance compatibility layer (`src/compat.php`) resolving PHP 8 property type invariance fatal errors on `$dohistory`, `$rightname`, and `$menu_option`.
- Fixed issue https://github.com/DonutsNL/samlsso/pull/169 by @beeone42: added call-time `samlsso_webdir()` and `samlsso_plugin_web_dir()` helpers resolving boot-time empty `url_base` regressions and relative ACS/SLO URL rejections in php-saml strict mode.
- Fixed issue https://github.com/DonutsNL/samlsso/pull/169 by @beeone42: added dual-version `User::sanitizeInput()` helper preserving Sanitizer on GLPI 11 while preventing missing class fatal errors on GLPI 12.
- Fixed issue https://github.com/DonutsNL/samlsso/pull/169 by @beeone42: hardened form rendering and template contexts against Twig `strict_variables` exceptions in GLPI 12 debug mode, and prevented local login lockout when configured IdPs are inactive.
- Added `Glpi12CompatTest.php` automated test suite to validate the GLPI 12 compatibility wiring, call-time webdir helpers, and anti-obfuscation rules.
- Updated `QueryExpression` in CronTask.php to `Glpi\DBAL\QueryExpression` for GLPI 12 database abstraction compatibility.
- Fixed TypeError in Auth.php by ensuring `auth_succeded` is assigned a strict boolean value matching GLPI 12 property type.
- Guarded `_glpi_csrf_token` and `Session::getNewCSRFToken()` calls across forms and templates to accommodate GLPI 12 header-based CSRF protection.
- Fixed plugin deactivation call in hook.php by replacing non-existent `deactivate()` method with native `unactivate()`.
- Refactored test harness and shims to simulate GLPI 12.0.0, aligning `CommonDBTM::getTable` signature with real core.
- Fixed permission denied error in ConfigIntegrityTest.php by using system temporary directory for key verification outside docroot.
- Added ADR 0026 documenting GLPI 12 compatibility refactoring, compatibility layer architecture, and test harness alignment.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/151 by introducing request-level configuration caching to reduce redundant SQL queries.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/47 where user ID and username in LoginState were corrupted during GLPI impersonation.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/145 where custom GLPI_MARKETPLACE_DIR paths caused 404/installation regressions - suggested by @albertogalisteo.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/141 with JIT rules test route opening missing plugin path - suggested by @KawanCostaNs.
- Fixed issue https://github.com/DonutsNL/samlsso/pull/144 to support GeneralizedTime X.509 certificate dates with validity dates beyond 2049 by @enricomv.
- Fixed issue https://github.com/DonutsNL/samlsso/pull/140 where LogoutResponse was incorrectly processed as AuthnResponse in Acs.php by @Siruv.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/149: Resolved CronTask session cleanup bugs, added 8-hour working day clamping default for retention values under 1 day, logged processed counts to events log, added manual action alerts, and replaced deprecated `\Html::convDateTime()` calls with a timezone-safe formatting helper.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/150: Optimized automated translations, added translation overrides JSON mapping, and utilized GLPI core translations for common buttons (`Save`, `Delete`, `Put in trashbin`) to prevent faulty translations.
- Feature: Added CronTask installation/upgrade deduplication to clean up legacy namespace records and duplicate actions upon plugin install/upgrade.
- Feature: Added post-upgrade/install Sanity Checker utility class to validate files, translation assets, tables, and column schemas, deactivating the plugin automatically on structural inconsistencies.
- Feature: Added ADR 0025 documenting the Sanity Checker and upgrade task deduplication logic.
- Fix: Refactored database query and loop assignments inside conditional checks to resolve CodeFactor's "Assignment in condition" warnings.
- Fix: Refactored translation logging messages in User defaults synchronization to use static literal strings and `sprintf` to resolve CodeFactor's "Unnecessary string concatenation" warnings.
- Fix: Replaced raw `TODO` in base64 mock private key template to resolve CodeFactor's "Unresolved TODO comment" warnings.
- Fix: Fixed a loop-overwriting bug in `getTabWarnings` where warning status (⚠️) on configuration tab panels was cleared and overwritten by subsequent clean fields.
- Fix: Resolved a parsing condition in `sp_certificate` and `idp_certificate` where validly parsed certificates skipped passing expiration and default/example certificate warnings to the form fields' errors property.

**V1.3.1**
- Fix: Resolved TypeError: noMethod() expects string, int given on undefined or custom database configuration fields in ConfigItem and LoginFlowItem.
- Fix: Implemented case-insensitive email comparison during JIT user synchronization on login to prevent duplicate `glpi_useremails` insert errors. (Related issues: https://github.com/DonutsNL/samlsso/issues/126, https://github.com/DonutsNL/samlsso/issues/127)
- Feature: Added dynamic FontAwesome CSS parser to populate the LOGIN ICON selector with all available installed icons, sorted alphabetically.
- Fix: Removed '. UTC' from datetime conversions in LoginState to resolve timezone mismatches and premature timeouts on servers not configured to UTC. (Related issue https://github.com/DonutsNL/samlsso/issues/124)
- Feature: Added timezone validation warning popout to timeout configuration settings to detect and display PHP vs Database timezone mismatches.
- Feature: Added ADR 0023 documenting the timezone fix and validation for login states.
- Fix: Applied raw filter to Twig error helper variables passed to form fields to prevent HTML auto-escaping, restoring warning/error popovers and yellow background highlighting.
- Fix: Resolved database migration race condition where `loginFlowTrace` column failed to upgrade to `TEXT` if it did not exist prior to update. (Related issue https://github.com/DonutsNL/samlsso/issues/123)
- Fix: Ensured the `location` column in the login states table does not receive a `null` value when `parse_url()` fails on malformed or empty URIs by defaulting to `'UNKNOWN'`. (Related issue https://github.com/DonutsNL/samlsso/issues/123)
- Fix: Resolved inactive session timeout bugs by replacing invalid database column queries in cleanSessionSAML CronTask with class constants and protecting the TIMED_OUT phase in evalGlpiAuth.
- Feature: Automatically disable and display warnings on inbound security fields when strict mode is disabled.
- Architecture: Added ADR 0022 documenting the decision to auto-disable inbound security options when strict is off and use prefix-based dynamic stylinrsg for warnings.
- Redesigned the configuration form fields layout to use a modern two-line strategy (Labels and tooltips on line 1, input controls on line 2), preventing squishing and making better use of the available space.
- Implemented soft yellow/warning background styling (via `.form-field-warning-row` class) and borders for rows with active warnings.
- Refactored warnings across all form fields (including those inside General, Transit, and Security tabs) to render elegantly as warning tooltips next to labels, hiding the original text messages.
- Refactored monolithic configForm.html.twig into separate sub-templates for each tab panel inside templates/configForm/.
- Wrapped all remaining hardcoded user-facing fields in Twig templates with i18n translation functions and formatted them for easy localization.
- Fixed translation of Service Provider fields (Entity ID, MetaUrl, AcsUrl, SloUrl) in Twig configuration form templates.
- Architecture: Added ADR 0015 documenting the design, implementation, and environment requirements for the translation automation tool.
- UI: Added a translatable warning tooltip icon next to the "SYNC ON LOGIN" field explaining potential data leak incidents from IDP configuration mistakes. Also formatted the conditional warnings for "ENFORCED" and "STRICT" fields in the same clean hoverable style.
- UI: Restructured the Security tab layout using Bootstrap columns to eliminate empty whitespace and grouped the settings logically into four categories: Enforcement & Sessions, User Provisioning, Inbound Security (IdP), and Outbound Security (SP).
- UI: Restructured the General, Transit, SP, and IdP configuration tabs into consistent card-based logical subject groups with neat right-aligned inputs and responsive layouts.
- Feature: Added inactivity timeout configuration setting allowing administrators to forcefully log out inactive user sessions after a specified duration (default is 0, which disables the inactivity check).
- Feature: Implemented passive ACS request evaluation during user logins to automatically clean up and forcefully expire stale pending authentication states.



**V1.3.0**
- Fix: Removed 'after' statements from database field migrations to prevent update/installation errors due to non-existent columns. (Related issue https://github.com/DonutsNL/samlsso/issues/119)
- Feature: Added proactive GLPI cache reset during plugin installation/upgrade using CacheManager::resetAllCaches(). (Related issue https://github.com/DonutsNL/samlsso/issues/119)
- Architecture: Added ADR 0014 documenting the design decision to clear GLPI cache during installation/upgrade. (Related issue https://github.com/DonutsNL/samlsso/issues/119)
- Fix: Resolved a critical nested form structure conflict in the Twig template (`configForm.html.twig`) that incorrectly triggered `forcelogoff` actions when saving configuration updates.
- Fix: Prevented SSO login/redirection flow interception on active administrator sessions by skipping `doAuth()` and local login blocks if `Session::getLoginUserID()` is active.
- Fix: Ensured the multiple active IDPs warning message is always displayed on the Enforce SSO field in the configuration UI when more than one IDP is active.
- Fix: Reset database session phase to `PHASE_INITIAL` when GLPI session is expired, ensuring SSO enforcement redirects work correctly for returning users with lingering cookies. (Related issue https://github.com/DonutsNL/samlsso/issues/25)
- Feature: Added configurable SAML request timeout fallback to automatically expire stale authentication states after a set duration (default 15 minutes) - by @eduardomozart
- Security Fix: Addressed local login SSO enforcement bypass securely using server-side session variable checks instead of a spoofable Referer check - by @eduardomozart
- Merged PR 114: Added country code 'ZZ' fallback tooltip and image display - by @eduardomozart
- Merged PR 115: Replaced custom copy buttons with native is_copyable attribute - by @eduardomozart
- Merged PR 116: Enforced access control checks with Session::checkRight and added user avatars - by @eduardomozart
- Merged PR 117: Separated translation links and added PO/POT generator - by @eduardomozart
- Merged PR 118: Added user fields matching support in rule criteria - by @eduardomozart
- Implemented configurable SAML claim mapping for GLPI user fields with predefined presets (Entra ID, Okta, Keycloak) and observed claims tracking.
- Refactored installation/uninstallation routines using a central class registry and single migration instance.
- Hardened logout and Single Logout (SLO) confirmation rendering, local logout redirection paths, and auto-login loop prevention.
- Added automated test validation pre-checks to the release packaging script.
- Fixed static analysis warnings, type declarations, compliance checks, and translation domain issues across source files.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/51 where user JIT creation bypassed the Identity Provider configuration.
- UI: Refactored the Backup & Restore section on the IDP list page into a collapsible panel triggered by a subtle outline toggle button, reducing visual weight while keeping the feature accessible.
- UI: Wrapped the "Template & View XML" tools on the Claim Mapping tab into a collapsible "Tools" panel, consistent with the Backup & Restore treatment.
- UI: Claim mappings are now ordered deterministically — enforced (system) mappings are always shown first, followed by manually added mappings in insertion order.
- Reliability: Replaced `::class` constants in the `PLUGIN_SAMLSSO_CLASSES` array in `setup.php` with fully-qualified string literals so the constant can be safely defined before the Composer autoloader is registered (i.e. when the plugin is disabled).
- Reliability: Added `include_once __DIR__ . '/vendor/autoload.php'` to `hook.php` so plugin classes are always resolvable during install/uninstall, even when `plugin_init_samlsso()` (which normally loads the autoloader) has not run.
- Reliability: Replaced `ClassName::getTable()` / `self::getTable()` calls inside `install()` and `uninstall()` lifecycle methods with `getTableForItemType(static::class)` across `Config`, `ClaimMap`, `ObservedClaim`, `Exclude`, and `LoginState`, using the GLPI-recommended function that performs pure string manipulation with no dependency on plugin state.
- Testing: Updated `LifecycleIntegrityTest.php` class parser to support both the legacy `::class` constant format and the new quoted string literal format in `PLUGIN_SAMLSSO_CLASSES`.
- Fix: Corrected signed `INT` foreign key columns (`configs_id` in `ObservedClaim` and `ClaimMap`; `idpId` in `LoginState`) to `INT UNSIGNED` to silence GLPI 11 deprecation warnings; added upgrade migrations to fix existing installations.
- Feature: Added `sync_on_login` configuration option to automatically update user claim mappings and rerun the rules engine on every successful user login.
- Refactored Claim Mappings to use class constants instead of raw strings for target fields and target types, improving consistency and maintainability.
- Refactored SAML claim resolution, defaults, and requirements validation logic out of `User.php` and into `ClaimMapEntity.php` helper methods.
- Decomposed large methods in `User.php`, `Acs.php`, and `LoginFlow.php` into descriptive private helper methods to improve readability.
- Standardized project-wide class layout and structure rules (constants at the top, chronological method ordering, and database schema hooks at the bottom) documented in ADR 0010.
- Cleaned up unused imports and normalized FQCN references across source files.
- Removed unused `SCHEMA_*` and `USERDATA` constants from `User.php` that are no longer referenced after the mapping refactor.
- Cleaned up unused and deprecated methods (`trackObservedClaim` in `ClaimMapEntity.php`; `setSamlResponseParams`, `setRequestParams`, and `isLoadedFromDb` in `LoginState.php`) detected by dead-code analysis.
- Feature: Added offline GeoIP originating country flag resolution. Client IPs are stored and matched using a high-performance binary search resolver (`GeoIPResolver`) on a compact local database (`ip_to_country.bin`). Flags are rendered as native browser emojis with full country hover tooltips in the session log UI.
- CLI Tool: Added `tools/update_geoip.php` to fetch DB-IP Lite country CSV databases and compile them into the optimized binary database format.
- Testing: Integrated `GeoIPTest.php` to verify offline database country matching and emoji flag conversions.
- Fix: Prevented SAML SSO auto-redirect logic from running on AJAX/sub-requests (e.g., translation fetch) to avoid session state phase corruption and ensure top-level pages correctly redirect to the IdP when SSO is enforced.
- Architecture: Added ADR 0011 documenting the decision to skip SAML SSO redirection on AJAX requests.
- Fix: Updated session log UI to render country flags using FlagCDN PNG images rather than native OS-dependent emoji characters, ensuring correct rendering on platforms like Windows.
- Fix: Automatically disable the SSO Enforce option (`enforce_sso`) via `ConfigEntity::validateAdvancedConfig()` when multiple active IDPs exist, and display a warning inline in the configuration form rather than as a redirect message.
- Architecture: Added ADR 0012 explaining the multi-IDP Enforce conflict resolution mechanism and the explicit design decision not to follow the GLPI standard redirect-based messages.
- Feature: Added administrative action to forcefully log off and disable users directly from the active sessions log table.
- Architecture: Added ADR 0013 documenting the design and security of the force logoff and disable user action.


**V1.2.7**
- Bugfix for regression bug in `acs.php:228` where method getErrors didnt exist https://github.com/DonutsNL/samlsso/issues/104

**V1.2.6**
- Security Fix: Resolved critical authentication bypass vulnerability in exclude path matching logic by parsing URL path component before matching.
- Security Fix: Implemented strict "Open Redirect" protection. The `redirect` parameter is now validated to allow only relative paths, preventing attackers from using GLPI as an open relay.
- Security Fix: Hardened error logs by implementing conditional redaction. Sensitive SAML data is now redacted by default unless "Debug" is explicitly enabled in the IDP configuration.
- Fix: Replaced non-existent `DBConnection::getDefaultDatabase()` with `$DB->dbdefault` for compatibility with GLPI 10.0+.
- Architecture: Added ADR 0002 documenting the rationale for LoginState hardening and DB compatibility fixes.
- Architecture: Added ADR 0003 documenting the new Integration Testing Strategy.
- Testing: Implemented a lightweight test harness in `tests/` with shims for GLPI core, allowing validation of core logic paths (Enforced redirect, Domain selection, Bypass) without a full GLPI environment.
- Documentation: Created `WIKI_UPDATES.md` and `PROPOSED_ISSUE_TESTABILITY.md` to guide future improvements.
- Improve generation scripts in tools directory to include more info.
- Improvement: Added index to logging table via installation/upgrade as suggested by @Neozlag
- Improvement: Reviewed and added completed es_AR translation
- Fix: Alter logout location preventing it from being processed to early
- Improvement: Added a warning about PHP memory_limit - by @eduardomozart
- Improvement: JIT handling: Remove default profiles only if profiles have been successfully assigned - by @eduardomozart
- Fix: Update User.php fix ENTITY_DEFAULT and PROFILE_DEFAULT variables undefined key warinings - by @eduardomozart
- Fix: Corrected constant name of entity for prepared not yet implemented reaply JIT function `src/LoginFlow/LoginFlowItem.php`:210 - by @eduardomozart
- Improvement: Check for numeric srtings too instead of pure int - by @tomas321. 

**V1.2.5 - BUGFIX RELEASE**
- Provide bugfix for critical bug https://github.com/DonutsNL/samlsso/issues/38.
- Fix incorrect plugin paths issue https://github.com/DonutsNL/samlsso/issues/41

**V1.2.4**
- Added webhook.php to excludes https://github.com/DonutsNL/samlsso/issues/32
- Added `.php` to excludes path in `Config.php` to make sure the 'add' button shows.
- Altered `getConfigIdByEmailDomain()` to handle multiple domains per IDP using comma seperated domain lists i.e. `domain1.com,domain1.nl,domain1.org`
- Altered the description of the userDomain field explaining the multiple domain option.
- Added basics in `performSamlSSO()` and `doAuth()` for Subject hinting, but this isnt supported by Entra. Maybe make this a configurable option in the future for IDPs that do support Subject hinting.
- Add acs exclusion in doAuth flow https://github.com/DonutsNL/samlsso/issues/29
- Remove excessive state inits in authFlow object.
- Fix issue in logout method causing warnings to be logged by Html object. https://github.com/DonutsNL/samlsso/issues/35
- Updated the credits in the Readme.md (long overdue sorry for that)
- Updated all the translation projects in https://app.transifex.com/quinquies/glpisaml/
- Added /api.php to excludes as requested by https://github.com/DonutsNL/samlsso/issues/36**



**V1.2.2**
- Corrected a router bug that caused the http header bag and response objects to be called with __toString()
- Added an additional Prerequisites check to validate the php cookie settings and block install if they are not correct (issue 13).
- Corrected small linting issues in the src files.
- Corrected the `login_name` field in the `LoginFlow.php` file to capture the login domains. (issue 16).
- Added `Config::getHideLoginFields()` if domain based idp selection is used.
- Added CSS to `LoginFlow::showLoginScreen()` to hide the password, source and rememeber fields when domain based auth is used and buttons are hidden.
- Implemented the `?bypass=1` getter to bypass the hidden fields and enforcement.
- Fixed the logo url being incorrect.
- Fixed redirects to browser sided redirects to make sure request chains are reset and not tainted.
- Added logic for the logout functionality.
- Added logout template.
- Fixed bypass logic making sure no loops occur.
- Fixed issue https://github.com/DonutsNL/samlsso/issues/27 with undefined tabs in twig.
- Fixed issue with state database not aligning state entries correctly after ACS redirect.
- Added logic for logout function https://github.com/DonutsNL/samlsso/issues/26
- Removed old, double init logic in state object.
- Fully Refined the state objects logic to prevent duplicate entries
- Implemented 'logout' catching mechanism that allows user to log out everywhere if desired.
- Added custom exceptions for saml State object not catched by design.
- Fix faulty Twig variable in configForm.
- Added logout URLs to controller
- Added logout URLs to config screen.


**V1.2.1**
- Added new bootstrap function to `setup.php` to register stateless paths.
- Disabled generic config tab untill fully implemented.
- Corrected typing issue in `LoginState.php:544` bool should be int.
- Corrected the authflow to seamlessly follow the GLPI auth.
- Added logic to reinitiate statefull redirect after stateless init at ACS.
- Removed deprecated CSRF_COMPLIANT hook.
- Fixed a few typing issues caused by enforcing strict mode in all PHP files.
- Bumped version to 1.2.1 to allow upgrade for those who tested with old crappy version.
- Updated the samlsso.xml and removed all old non compatible codeberg artifacts.
- Removed unsupported DisableCsrfCheck decorators from Controller routes.
- Refactored the `mkzip.sh` and added it to the tools directory.
- Upgraded onelogin/php-saml (4.2.0 => 4.3.0) to latest release
- Fixed branding and excludes in mkzip.sh
- Change to trigger git 

**v1.2.0**
- Updated the XMLseclibs to version 3.1.3
- Renaming plugin to samlSSO for better searchability
- Updated the credits
- `Config.php`:270 `getIsEnforced()` added `is_deleted` check to enforced query.
- Added `return ''; // Unreachable return but prevents PHP0405-no return linting error.` various places
- Fix non functional linting errors in `src/LoginFlow/User.php` paths without return value
- Fix constant and method naming in `hook.php`
- Fix constant and method naming in `Config/ConfigForm.php`
- Fix constant and method naming in `Config/ConfigEntity.php`
- Fix constant and method naming in `Config/ConfigItem.php`
- Renamed all the file headers
- Updated `samlsso.xml` with new name and repo.
- Added strict typechecking and corrected all typing issues `declare(strict_types=1);` 
-    @see: https://www.php.net/manual/en/language.types.declarations.php.

**v1.1.11**
- Removed the version validation from ConfigForm.php as its no longer used
- Added additional file logging for JIT operations to enable debugging for issues
- Optimized logrules for readability
- https://codeberg.org/QuinQuies/glpisaml/issues/111
- Added .pot generation script to tests folder
- Added fr_FR translations from https://app.transifex.com/quinquies/glpisaml/language/fr/
- Cleaned unused files and corrected file properties
- Added a fallback to use the nameId as email field if the email claim was set but didnt contain a valid emailadress.
- Added a not empty check to the emailadress claim and will now be ignored if the property was set with no actual value.

**v1.1.10**
- In preparation for 1.2.0
- https://codeberg.org/QuinQuies/glpisaml/issues/61
- https://codeberg.org/QuinQuies/glpisaml/issues/46
-  Added logic to automatically enforce saml configuration if there is only one configured with enforce enabled.
- Update template with compression enabled
- Added message with 'version' after install for saas validation purposes
- Upped minimal version: https://codeberg.org/QuinQuies/glpisaml/issues/65#issuecomment-2066465
- Upped the minimal required version in `setup.php` to GLPI 10.0.11 because plugin does not use deprecated `query()` but newer `doQuery()` instead.
- fixed warning in User.php file https://codeberg.org/QuinQuies/glpisaml/issues/71
- Removed unused 'use' inclusion in front/config.php https://codeberg.org/QuinQuies/glpisaml/issues/73
- Added gitignore to stop phpunit and deps from being send to the repository
- Updated `onelogin/php-saml` to latest version 4.2.0 @see https://github.com/SAML-Toolkits/php-saml/releases
- Changed `ConfigEntity.php:508` to add `?idpId=` to the ACS service URL send to the Idp for capture at ACS.
- Added wiki reference `https://codeberg.org/QuinQuies/glpisaml/wiki/ACS.php` in the acs error page to provide more information.
- Fully refactored `LoginFlow/Acs.php` and `/front/acs.php` to work arround the login cookie requirement.
- Fully refactored `src/LoginState.php` object to store and process additional fields samlRequestId, samlResponseId (InResponseTo), requestUnsolicited fields
- Refactored method LoginFlow::doAuth() for https://codeberg.org/QuinQuies/glpisaml/issues/45
- Refactored method LoginFlow::performSamlSSO for https://codeberg.org/QuinQuies/glpisaml/issues/45
- Added `tests/createPot.sh` to create a POT file from the php source using xgettext
- Added `locals/glpiSaml.pot` to allow users to translate and create localization files (PO/PM)
- Added https://app.transifex.com/quinquies/glpisaml/ project for public translations
- Started refactoring LoginFlow.php to include a LoginFlow configuration page.
- Fixed always enforced bug with only one idp configured and enforce off.
- Added loginFlow trace to the log idp page
- Removed extended location logging very problematic;
- Re-enabled the bypass option after removing no longer existing method;
- Extended update procedure to clean state table, and remove old cookies;
- Added locales for translations;
- Removed version check (causing timeouts if codeberg is offline)
- Removed hidden fields on enforce so enforce can be bypassed.

**v1.1.5**
- We found that the return value bool:false on the POST_INIT hook might break cron functionality in very nasty ways (removing user profiles after succesfull mail import for instance!) as a quick fix we now return null, making sure other components are not influenced by anything we did 'not' return to the calling plugin function. 

**v1.1.4**
- Aligned the menu icons and naming with TecLib's Oauth SSO Applications plugin in `src/Config.php`
- Altered `name` in `setup.php:122` to reflect plugin name correctly with value `Glpisaml`
- Altered `homepage` in `setup.php:125` to reflect correct GIT repository at `Codeberg.org`
- Altered menu name `src/RuleSaml.php` method `getTitle()` return value to  `JIT import rules`.
- Altered menu name `src/RuleSamlCollection.php` method `getTitle()` return value to `Jit import rules` 
- Altered JIT button name in `src/Config.php:142` to match the RuleCollection menu name `Jit import rules` 
- Added additional validation and warning to check if the example certificate `withlove.from.donuts.nl` is used in the configuration in `src/config/ConfigItem.php:599`.
- Added `dashboard.php` to the default excludes to prevent the plugin being called multiple times on dashboard load.
- Corrected spelling and typo's throughout the plugin files.
- Addressed issue https://codeberg.org/QuinQuies/glpisaml/issues/36
- Corrected and finished Excludes configuration. Excluded paths will now not be processed, but will be logged (for debugging purposes) in the `glpi_plugin_glpisaml_loginstates` table.
- Fixed https://codeberg.org/QuinQuies/glpisaml/issues/42
- Refactored IF statement in `loginFlow.php:138` to be more compact.
- Moved the `getUserInputFieldsFromSamlClaim` method from the `LoginFlow` class to `LoginFlow\User\` class.
- Simplified the `getUserInputFieldsFromSamlClaim` by only supporting the soap identity claims.
- Simplified the `getUserInputFieldsFromSamlClaim` by trusting the nameId validation of OneLogin and allowing all passed values.
- Made sure that `nameId` is now always mapped to `glpiUser->name` field
- Previous 2 changes now also explicitly allow you to use `samaccountname` as valid nameId
- Added `http://schemas.xmlsoap.org/ws/2005/05/identity/claims/firstname` or `givenname` claim to be processed by userJit if provided
- Added `http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname` claim to be processed by userJit if provided
- Added `http://schemas.xmlsoap.org/ws/2005/05/identity/claims/mobilephone` claim to be processed by userJit if provided
- Added `http://schemas.xmlsoap.org/ws/2005/05/identity/claims/telephonenumber` claim to be processed by userJit if provided
- Added `http://schemas.xmlsoap.org/ws/2005/05/identity/claims/groups` to be passed to the rules engine (no match rule yet)
- Added `http://schemas.xmlsoap.org/ws/2005/05/identity/claims/jobtitle` to be passed to the rules engine (no match rule yet)
- Added `user-fields->authtype = 4 (other)` to Jit Created users as discussed https://codeberg.org/QuinQuies/glpisaml/issues/41
- JIT wil now populate sync_date property
- Added location claims to the logic, they are currently not handled.
- Implemented the `enforced` option, enforcing automatic login if the user selected its IdP in a previous session using a `enforce_saml` cookie.
- Implemented the `?bypass=1` option to bypass the enforced login for troubleshooting.
- Enforce will now also `hide` the password,
- Users are now allowed to select the correct idp using a `?samlIdpId=ID` get parameter for Idp Initiated logins. 

**v1.1.3**
- Added logic to store the initial sessionId for reference in state table.
- Altered error messages in `/front/meta.php` to be more generic less helpful for added security
- Added method `getConfigIdByEmailDomain` to `src/config.php` to get IDP ID based on given CONF_DOMAIN
- Added Method `getConfigDomain` to `src/configEntity.php` to fetch the CONF_DOMAIN from the fetched entity used
  to evaluate if the button for the entity needs to be shown.
- Extended `doAuth` in `src/LoginFlow.php` to also evaluate username field in login screen and match it
  with idp configured userdomain. This allows a user to simply 'provide' its username and press login triggering
  a saml request if the domain in the username matches a given idp's userdomain configuration.
- Updated the loginbutton logic to not show on the login page if there are no buttons to show.
- Added a test `popover` in the config screen with the `copy meta url button` to see if that cleans 
  the configuration further and how that would look and feel. Considering to leave it and see if 
  and how ppl respond to it.
- Added logic to `generateForm` in `src\Config\ConfigForm.php` to detect if the login button will be hidden
- Added errorhelpers to `templates/configForm.html.twig` to warn users the login button will be hidden.
- Added errorhelpers to `templates/configForm.html.twig` to explain userdomain behavior if configured.
- Fixed issue https://codeberg.org/QuinQuies/glpisaml/issues/20
- Added saml cookies to help plugin correctly track session on redirect with session.cookie_samesite = strict.
- Added additional logic to `src/loginState.php` hardening the logic
- Added meta redirect to deal with session.cookie_samesite = strict after Saml Redirect back to GLPI
- Added additional explanations to config item in `src/Config/ConfigItem.php`
- Fixed issue https://codeberg.org/QuinQuies/glpisaml/issues/30
- Added `is_deleted = 0` filter in `src/Config.php` method `getLoginButtons`
- Fixed issue https://codeberg.org/QuinQuies/glpisaml/issues/31
- Implemented https://codeberg.org/QuinQuies/glpisaml/issues/14
- Added additional validations on certificate validation method in `src/Config/ConfigItem.php` method `parseX509Certificate` 
